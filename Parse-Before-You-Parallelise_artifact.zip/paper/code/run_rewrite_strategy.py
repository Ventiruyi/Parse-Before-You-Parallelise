r"""论文一：sub_l 代数重写并行策略的端到端测量（审稿"回退无价值"批评的正面回应）。

语义与合法性
------------
初值 0 的 ``acc -= e`` 顺序值恒等于 ``-Σe``（mod 2^32），而 ``-(Σ_lane 和)``
与 ``-Σe`` 在 mod 2^32 加法下恒等——因此 **sub_l 存在保持语义的代数重写**：
每条 lane 改用普通加法累加，合并用加法，输出统一取负。重写后 lane 间数据
无关，任何 ``L`` 整除 ``N`` 的划分都合法（与结合归约同权）。sub_r 的
``acc = e - acc`` 交替形式不存在同类重写，保守回退保留。

策略语义（rewrite）
-------------------
- sub_l：lane 数取预算内最大因子（与 budget/parse-driven 同权），生成时用
  重写形式；
- sub_r：无重写可用，退回 L=1（与 rolled 同权）；
- 结合归约：与 parse-driven 完全一致（重写恒等）。

测量协议与主实验完全一致：gcc 真执行为参考、独立 Python 模型交叉检查、
RTL 仿真只打印实测值、功能通过后送完整 ECP5 后端。
"""
from __future__ import annotations

import csv
import json
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

from hls_dataset import KERNELS, make_vectors
from hls_flow import parse_kernel
from run_hls_experiment import (
    LANE_BUDGET, VECTOR_ROWS, backend_metrics, find_tool, run_backend,
    run_gcc_reference, simulate,
)

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = ROOT / "paper" / "results" / "rewrite_strategy"


def rewritten(constraint, lanes_budget: int):
    """rewrite 策略的 (constraint, lanes)：sub_l 代数重写并行；sub_r 回退 L=1。"""
    if constraint.mode == "reduce" and constraint.reduce_op == "sub_l":
        legal = [l for l in range(1, constraint.count + 1) if constraint.count % l == 0 and constraint.count // l >= 2]
        lanes = max(l for l in legal if l <= lanes_budget) if any(l <= lanes_budget for l in legal) else 1
        return replace(constraint, reduce_op="+", rewrite=True), lanes
    if constraint.mode == "reduce" and not constraint.associative:
        return constraint, 1  # sub_r：无重写可用，保守回退
    legal = [l for l in range(1, constraint.count + 1)
             if constraint.count % l == 0 and l <= lanes_budget]
    return constraint, max(legal)


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    incomplete = {
        "experiment": "sub_l_rewrite_parallel_strategy",
        "complete": False,
        "note": "本轮实验尚未跑完；complete=false 的清单不可引用。",
    }
    (OUTPUT / "rewrite_strategy.json").write_text(
        json.dumps(incomplete, ensure_ascii=False, indent=2), encoding="utf-8")

    import shutil
    gcc = shutil.which("gcc") or "gcc"
    iverilog = find_tool("iverilog", ROOT)
    vvp = find_tool("vvp", ROOT)

    rows: list[dict[str, Any]] = []
    for kernel in KERNELS:
        source = kernel.c_source()
        constraint = parse_kernel(source)
        vectors = make_vectors(kernel, VECTOR_ROWS, seed=12345)
        reference = run_gcc_reference(gcc, OUTPUT, kernel, vectors)
        model = [kernel.reference_packed(a, b) for a, b in vectors]
        model_agrees = model == reference

        rw_constraint, lanes = rewritten(constraint, LANE_BUDGET)
        rolled_lanes = 1
        outcome = simulate(iverilog, vvp, OUTPUT, kernel, rw_constraint, lanes,
                           "rewrite_s0", vectors)
        functional = outcome["compilable"] and outcome["values"] == reference
        row: dict[str, Any] = {
            "kernel": kernel.name,
            "mode": kernel.mode,
            "reduce_op": constraint.reduce_op,
            "rewritten": bool(rw_constraint.rewrite),
            "lanes": lanes,
            "cycles": outcome["cycles"],
            "rolled_cycles": kernel.count,
            "compilable": outcome["compilable"],
            "functional_pass": bool(functional),
            "model_agrees_with_gcc": model_agrees,
            "vectors": len(vectors),
        }
        if functional:
            case_dir = OUTPUT / f"flow_{kernel.name}"
            case_dir.mkdir(parents=True, exist_ok=True)
            rtl_file = OUTPUT / f"{kernel.name}__rewrite.v"
            rtl_file.write_text(outcome["rtl"], encoding="utf-8")
            code, manifest = run_backend(ROOT, rtl_file, "kernel", case_dir)
            row["flow_returncode"] = code
            if manifest is not None:
                row.update(backend_metrics(manifest))
        rows.append(row)

    ok = [r for r in rows if r["functional_pass"]]
    sub_l = [r for r in rows if r["reduce_op"] == "sub_l"]
    sub_l_ok = [r for r in sub_l if r["functional_pass"]]
    sub_l_ratio = [r["rolled_cycles"] / r["cycles"] for r in sub_l_ok]
    result = {
        "experiment": "sub_l_rewrite_parallel_strategy",
        "complete": True,
        "design": {"kernels": len(KERNELS), "vector_rows": VECTOR_ROWS,
                   "lane_budget": LANE_BUDGET},
        "rows": rows,
        "summary": {
            "kernels": len(rows),
            "kernels_functional": len(ok),
            "sub_l_kernels": len(sub_l),
            "sub_l_functional": len(sub_l_ok),
            "sub_l_parallel_ratio": round(min(sub_l_ratio), 2) if sub_l_ratio else None,
            "model_gcc_agreement": sum(1 for r in rows if r["model_agrees_with_gcc"]),
        },
        "note": (
            "sub_l 的重写形式（lane 用 + 累加、输出取负）由初值 0 的顺序值恒等式 "
            "-Σe = -(Σ lane 和)（mod 2^32）保证语义；sub_r 无同类重写，保守回退 L=1；"
            "结合归约上重写与 parse-driven 恒等。参考值来自 gcc 对同一 C 源的真执行。"
        ),
    }
    (OUTPUT / "rewrite_strategy.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    with (OUTPUT / "rewrite_strategy.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = ["kernel", "reduce_op", "rewritten", "lanes", "cycles", "rolled_cycles",
                  "functional_pass", "lut", "ff", "dsp", "fmax_mhz"]
        writer = __import__("csv").DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in fields})
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
