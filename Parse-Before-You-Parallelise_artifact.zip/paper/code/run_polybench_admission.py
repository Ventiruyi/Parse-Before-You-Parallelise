"""对原始 PolyBench/C 源文件的论文一受控前端准入研究。

这不是端到端 HLS 基准：parse_kernel 有意只接受单循环、固定 N、登记元素表达式
与登记归约/映射语句的生成契约。本脚本逐文件记录 first-failure，因此拒绝也可审计。
"""
from __future__ import annotations
import json
from collections import Counter
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from hls_flow import parse_kernel
ROOT=Path(__file__).resolve().parents[2]
SRC=ROOT/'data'/'PolyBenchC-4.2.1'
OUT=ROOT/'paper'/'results'/'polybench_admission.json'
def reason(error):
 text=str(error)
 if ' #define N' in text or '找到 #define N' in text:return 'no_fixed_N_contract'
 if 'for' in text:return 'loop_shape_or_nesting'
 if '元素表达式' in text:return 'body_not_single_registered_element'
 if '归约语句' in text:return 'reduction_statement_not_registered'
 return 'other_contract_mismatch'
def main():
 rows=[]
 for f in sorted(SRC.rglob('*.c')):
  if 'utilities' in f.parts or f.name=='Nussinov.orig.c':continue
  try:
   c=parse_kernel(f.read_text(encoding='utf-8',errors='replace'))
   rows.append({'file':str(f.relative_to(SRC)).replace('\\','/'),'accepted':True,'mode':c.mode,'operator':c.reduce_op})
  except ValueError as e:
   rows.append({'file':str(f.relative_to(SRC)).replace('\\','/'),'accepted':False,'reason':reason(e),'detail':str(e)})
 rejected=Counter(r['reason'] for r in rows if not r['accepted'])
 result={'experiment':'polybench_raw_source_admission','scope':'raw PolyBench/C 4.2.1 benchmark kernels, excluding utilities and duplicate original','files':len(rows),'accepted':sum(r['accepted'] for r in rows),'rejected':len(rows)-sum(r['accepted'] for r in rows),'rejection_reasons':dict(sorted(rejected.items())),'rows':rows,'claim':'front-end admission only; rejected programs are not lowered to RTL'}
 OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
