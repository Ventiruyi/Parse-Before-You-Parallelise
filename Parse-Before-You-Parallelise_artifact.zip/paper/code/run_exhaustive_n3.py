"""Exhaustively check N=3, 4-bit subtraction reductions against emitted RTL."""
from __future__ import annotations

import itertools
import json
from pathlib import Path

from hls_dataset import Kernel
from hls_flow import parse_kernel
from run_hls_experiment import find_tool, simulate


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    output = root / "paper" / "results" / "exhaustive_n3"
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    for op in ("sub_l", "sub_r"):
        kernel = Kernel(f"{op}_id_n3w4", 3, 4, "id", op, "reduce")
        constraint = parse_kernel(kernel.c_source())
        vectors = [(list(a), [0, 0, 0]) for a in itertools.product(range(16), repeat=3)]
        reference = [kernel.reference_packed(a, b) for a, b in vectors]
        for policy, lanes in (("rolled", 1), ("illegal_parallel", 3), ("parse_driven", 1)):
            outcome = simulate(find_tool("iverilog", root), find_tool("vvp", root), output,
                               kernel, constraint, lanes, policy, vectors)
            failures = sum(got != expected for got, expected in zip(outcome["values"], reference))
            rows.append({"operator": op, "policy": policy, "lanes": lanes,
                         "vectors": len(vectors), "compiled": outcome["compilable"],
                         "outputs": len(outcome["values"]), "failures": failures,
                         "agreement": (len(vectors) - failures) / len(vectors),
                         "rtl_sha256": outcome["rtl_sha256"]})
    summary = {"experiment": "exhaustive_n3_subtraction",
               "domain": "all 4-bit triples; N=3; 2*4096 input vectors",
               "reference": "independent Python Kernel.reference_packed", "results": rows}
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
