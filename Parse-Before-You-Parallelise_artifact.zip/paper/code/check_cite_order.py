#!/usr/bin/env python3
# 引用顺序与完整性核查：首次引用序 vs 文献表序、未引用条目
import re
import sys

for p in ('paper',):
    s = open(f'{p}/submission/main.tex', encoding='utf-8').read()
    if r'\begin{thebibliography}' in s:
        body = s.split(r'\begin{thebibliography}')[0]
        bib = re.findall(r'\\bibitem\{(\w+)\}', s)
        label = 'thebibliography'
    else:
        body = s
        bbl = open(f'{p}/submission/main.bbl', encoding='utf-8').read()
        bib = re.findall(r'\\bibitem(?:\[[^\]]*\])?\{(\w+)\}', bbl)
        label = 'bbl'
    first = {}
    for m in re.finditer(r'\\cite\{([^}]*)\}', body):
        for k in m.group(1).split(','):
            k = k.strip()
            if k and k not in first:
                first[k] = len(first)
    order_first = [k for k, _ in sorted(first.items(), key=lambda x: x[1])]
    inv = []
    for i, b in enumerate(bib):
        if b in first:
            fi = order_first.index(b)
            # 该文献在表中的序号 i 应与首引序一致（允许并列）
            pass
    # 逆序对：文献表中 b 在 a 前，但 a 的首引早于 b
    pos = {b: i for i, b in enumerate(bib)}
    inversions = 0
    for a_i, a in enumerate(order_first):
        for b_i, b in enumerate(order_first):
            if b_i > a_i and pos.get(a, 10**9) > pos.get(b, 10**9):
                inversions += 1
                break
    uncited = [b for b in bib if b not in first]
    print(f'{p} ({label}): bib={len(bib)} cited={len(first)} 首引链异常={inversions} 未引用={uncited}')
