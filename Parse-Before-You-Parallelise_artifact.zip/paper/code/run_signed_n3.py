"""Controlled signed-input extension: exhaustive N=3, 4-bit two's-complement subtraction.

The accumulator is explicitly uint32_t/32-bit RTL, so wraparound remains defined.
"""
from __future__ import annotations

import itertools
import json
from pathlib import Path


def u32(value: int) -> int:
    return value & 0xFFFFFFFF


def signed4(bits: int) -> int:
    return bits - 16 if bits & 8 else bits


def fold(op: str, values: tuple[int, ...]) -> int:
    acc = 0
    for bits in values:
        elem = signed4(bits)
        acc = u32(acc - elem) if op == "sub_l" else u32(elem - acc)
    return acc


def illegal_merge(op: str, values: tuple[int, ...]) -> int:
    partials = [fold(op, (value,)) for value in values]
    return u32(partials[0] - partials[1] - partials[2])


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    output = root / "paper" / "results" / "signed_n3"
    output.mkdir(parents=True, exist_ok=True)
    vectors = list(itertools.product(range(16), repeat=3))
    rows = []
    for op in ("sub_l", "sub_r"):
        reference = [fold(op, vector) for vector in vectors]
        for policy, lanes in (("rolled", 1), ("illegal_parallel", 3), ("parse_driven", 1)):
            actual = reference if lanes == 1 else [illegal_merge(op, vector) for vector in vectors]
            failures = sum(got != expected for got, expected in zip(actual, reference))
            rows.append({"operator": op, "policy": policy, "lanes": lanes,
                         "vectors": len(vectors), "failures": failures,
                         "agreement": (len(vectors) - failures) / len(vectors)})
    summary = {"experiment": "signed_two_complement_n3",
               "domain": "all signed 4-bit triples; N=3; 2*4096 cases",
               "contract": "inputs sign-extended to a 32-bit modular accumulator",
               "results": rows}
    (output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
