#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define N 4
#define WMASK 0xFFu
typedef uint8_t elem_t;

uint32_t kernel(const elem_t *a, const elem_t *b) {
    uint32_t acc = 0u;
    for (int i = 0; i < N; ++i) {
        uint32_t e = (uint32_t)(a[i]) + (uint32_t)(b[i]);
        acc = (e) > acc ? (e) : acc;
    }
    return acc;
}

int main(int argc, char **argv) {
    FILE *fp = fopen(argv[1], "r");
    if (!fp) return 2;
    int rows = 0;
    if (fscanf(fp, "%d", &rows) != 1) return 2;
    elem_t a[N], b[N];
    for (int r = 0; r < rows; ++r) {
        for (int i = 0; i < N; ++i) { unsigned t = 0; if (fscanf(fp, "%u", &t) != 1) return 2; a[i] = (elem_t)t; }
        for (int i = 0; i < N; ++i) { unsigned t = 0; if (fscanf(fp, "%u", &t) != 1) return 2; b[i] = (elem_t)t; }
        printf("%u\n", (unsigned)kernel(a, b));
    }
    fclose(fp);
    return 0;
}
