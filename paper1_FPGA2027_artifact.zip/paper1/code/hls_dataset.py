"""论文一：受控 kernel 数据集、C 参考实现与激励向量。

数据集的两类样本
----------------
1. **可生成 kernel**（``KERNELS``）：一阶归约与逐元素映射两类循环，规模与运算
   组合展开。每个 kernel 都有真实 C 源码，用 **gcc 真编译真运行**得到参考输出
   —— 生成 RTL 再与 gcc 的输出逐向量比对。参考值不来自 RTL，也不来自手写常量。
2. **风险片段**（``RISK_SNIPPETS``）：动态内存、递归、函数指针、可变长数组等
   不可综合构造，以及必须不被误报的干净片段。它们来自
   ``run_parser_experiment`` 的受控集，直接复用而不是另抄一份，避免两处口径漂移。

为什么 kernel 只用无符号整型
----------------------------
C 的有符号溢出是未定义行为，而 Verilog 的加法是模 $2^n$ 回绕。若用有符号类型，
"gcc 输出与 RTL 输出逐向量相等"就不再是一个有定义的命题。全部使用
``uint16_t`` / ``uint32_t`` 后，两侧语义都是模回绕，比对才有意义。
"""
from __future__ import annotations

import random
import zlib
from dataclasses import dataclass
from typing import Any, Iterator

# ---------------------------------------------------------------------------
# kernel 定义
# ---------------------------------------------------------------------------

ELEM_FUNCS: dict[str, str] = {
    "id": "{a}",
    "mul": "(uint32_t)({a}) * (uint32_t)({b})",
    "add": "(uint32_t)({a}) + (uint32_t)({b})",
    "xor": "(uint32_t)({a}) ^ (uint32_t)({b})",
}

# 归约算子：C 语句模板 + 初值 + 是否结合（决定跨通道合并是否保序）
REDUCE_OPS: dict[str, dict[str, Any]] = {
    "+": {"stmt": "acc += {e};", "init": "0u", "associative": True, "merge": "+"},
    "max": {"stmt": "acc = ({e}) > acc ? ({e}) : acc;", "init": "0u", "associative": True, "merge": "max"},
    "min": {"stmt": "acc = ({e}) < acc ? ({e}) : acc;", "init": "0xFFFFFFFFu", "associative": True, "merge": "min"},
    "sub_l": {"stmt": "acc -= {e};", "init": "0u", "associative": False, "merge": "-"},
    "sub_r": {"stmt": "acc = ({e}) - acc;", "init": "0u", "associative": False, "merge": "-"},
}

REDUCE_LABEL = {"+": "sum", "max": "max", "min": "min", "sub_l": "sub-l", "sub_r": "sub-r"}


def pack_fields(values: list[int], width: int) -> int:
    """把元素列表按**低位在前**拼成一个宽位向量。

    这是本项目里"元素数组"与"一条 Verilog 位向量"之间唯一的约定，被两处使用：
    测试台构造 ``i_a``/``i_b``，以及 map 模式下把 Python 参考模型的元素列表压成
    与 gcc 参考输出同一表示形式以便逐值比对。凡是需要打包的地方都调用本函数，
    不许各自写一份 —— 两份实现一旦漂移，比对就会在"看起来都对"的情况下出错。
    """
    packed = 0
    for index, value in enumerate(values):
        packed |= (int(value) & ((1 << width) - 1)) << (index * width)
    return packed


@dataclass(frozen=True)
class Kernel:
    name: str
    count: int
    width: int
    elem: str
    reduce: str | None      # None 表示 map 模式
    mode: str               # "reduce" | "map"

    @property
    def associative(self) -> bool:
        if self.reduce is None:
            return True
        return bool(REDUCE_OPS[self.reduce]["associative"])

    @property
    def out_width(self) -> int:
        return self.width if self.mode == "map" else 32

    def c_source(self) -> str:
        mask = f"0x{(1 << self.width) - 1:X}u"
        lines = [
            "#include <stdio.h>",
            "#include <stdlib.h>",
            "#include <stdint.h>",
            f"#define N {self.count}",
            "#define WMASK " + mask,
            # 元素类型固定用 uint8_t 承载，最大值由 WMASK 截断，与 RTL 的
            # W 位窗口一致（用 uint4_t 之类的类型在 C 里并不存在）。
            "typedef uint8_t elem_t;",
            "",
        ]
        if self.mode == "reduce":
            spec = REDUCE_OPS[self.reduce]
            lines += [
                "uint32_t kernel(const elem_t *a, const elem_t *b) {",
                f"    uint32_t acc = {spec['init']};",
                "    for (int i = 0; i < N; ++i) {",
                f"        uint32_t e = {ELEM_FUNCS[self.elem].format(a='a[i]', b='b[i]')};",
                f"        {spec['stmt'].format(e='e')}",
                "    }",
                "    return acc;",
                "}",
                "",
            ]
        else:
            lines += [
                "void kernel(const elem_t *a, const elem_t *b, elem_t *y) {",
                "    for (int i = 0; i < N; ++i) {",
                f"        y[i] = (elem_t)(({ELEM_FUNCS[self.elem].format(a='a[i]', b='b[i]')}) & WMASK);",
                "    }",
                "}",
                "",
            ]
        lines += [
            "int main(int argc, char **argv) {",
            "    FILE *fp = fopen(argv[1], \"r\");",
            "    if (!fp) return 2;",
            "    int rows = 0;",
            "    if (fscanf(fp, \"%d\", &rows) != 1) return 2;",
            "    elem_t a[N], b[N];",
            "    for (int r = 0; r < rows; ++r) {",
            # 读入一律经过 unsigned int 再截断，**不用 C99 的 `%hhu`**。
            # 这不是风格问题：在本机 MinGW（链接 msvcrt.dll）上实测，`%hhu` 会按
            # 4 字节宽度写入 1 字节的 elem_t，越界 3 字节并破坏相邻局部变量 ——
            # 参考程序因此只算了一行、且部分元素被清零，给出**错误的参考值**，
            # 而退出码仍是 0，从外部看毫无异常。参考值一旦错了，后面所有
            # "RTL 与参考值比对"的结论就全部失效，所以这里必须用无长度修饰符的
            # `%u` 读进 unsigned 再显式转换。
            "        for (int i = 0; i < N; ++i) { unsigned t = 0;"
            " if (fscanf(fp, \"%u\", &t) != 1) return 2; a[i] = (elem_t)t; }",
            "        for (int i = 0; i < N; ++i) { unsigned t = 0;"
            " if (fscanf(fp, \"%u\", &t) != 1) return 2; b[i] = (elem_t)t; }",
        ]
        if self.mode == "reduce":
            lines.append("        printf(\"%u\\n\", (unsigned)kernel(a, b));")
        else:
            lines += [
                "        elem_t y[N];",
                "        kernel(a, b, y);",
                "        for (int i = 0; i < N; ++i) printf(\"%u%c\", (unsigned)y[i], i + 1 == N ? '\\n' : ' ');",
            ]
        lines += ["    }", "    fclose(fp);", "    return 0;", "}", ""]
        return "\n".join(lines)

    def python_reference(self, a: list[int], b: list[int]) -> int | list[int]:
        """独立参考模型（不是从 C 翻译，而是按规格重写），用于第三重交叉检查。"""
        mask = (1 << 32) - 1
        products = [_elem_value(self.elem, x, y) for x, y in zip(a, b)]
        if self.mode == "map":
            return [value & ((1 << self.width) - 1) for value in products]
        spec = REDUCE_OPS[self.reduce]
        acc = _c_uint_literal(spec["init"])
        for value in products:
            if self.reduce == "+":
                acc = (acc + value) & mask
            elif self.reduce == "max":
                acc = max(acc, value)
            elif self.reduce == "min":
                acc = min(acc, value)
            elif self.reduce == "sub_l":
                acc = (acc - value) & mask
            else:
                acc = (value - acc) & mask
        return acc

    def reference_packed(self, a: list[int], b: list[int]) -> int:
        """与 gcc 参考输出**同表示形式**的参考值，供逐值比对使用。

        ``python_reference`` 在 map 模式下返回元素列表（模型的自然形式），而参考
        程序把整行结果打印成一串数、由驱动打包成一个整数。若直接比较"列表 vs
        整数"，两者永远不相等 —— 这会让"模型与 gcc 是否一致"这道交叉检查恒定
        失败，从而把真实的检查能力伪装成 0。这里显式对齐表示形式。
        """
        value = self.python_reference(a, b)
        if self.mode == "map":
            return pack_fields(value, self.width)
        return value


def _c_uint_literal(text: str) -> int:
    """把 C 的无符号字面量（``0u`` / ``0xFFFFFFFFu``）解析成 Python 整数。

    C 的 ``u``/``U``/``l``/``L`` 后缀在 Python 里不存在，直接 ``int(text, 0)`` 会
    抛 ``ValueError``。这里显式剥掉后缀再按前缀定进制，不做任何静默兜底。
    """
    cleaned = text.strip().rstrip("uUlL")
    return int(cleaned, 0)


def _elem_value(elem: str, a: int, b: int) -> int:
    mask = (1 << 32) - 1
    if elem == "id":
        return a
    if elem == "mul":
        return (a * b) & mask
    if elem == "add":
        return (a + b) & mask
    return (a ^ b) & mask


def _build_kernels() -> tuple[Kernel, ...]:
    """kernel 家族：规模 × 归约算子 × 元素函数。

    规模固定为 4 与 8，元素位宽固定 8 bit：输入总线宽 $N\\times W$ 位，全部
    元素并行送入时要占 $2\\cdot N\\cdot W$ 个顶层端口位。ECP5-25F 的 CABGA256
    封装只有 197 个可用 IO，$N=8,W=8$ 时正好是 128 位输入加少量控制位，
    再大就会因为 IO 不够而无法布局布线 —— 这是真实的器件约束，不是可以
    悄悄放大的参数。
    """
    kernels: list[Kernel] = []
    for count in (4, 8):
        for reduce in ("+", "max", "sub_l", "sub_r"):
            for elem in ("id", "mul", "add"):
                kernels.append(
                    Kernel(
                        name=f"reduce_{REDUCE_LABEL[reduce]}_{elem}_n{count}",
                        count=count, width=8, elem=elem, reduce=reduce, mode="reduce",
                    )
                )
    # 映射模式要把整块结果并行送出，所以总线位宽是 N*W 的三倍（两个输入加一个
    # 输出）；(N=8, W=8) 会占 195 个 IO，逼近 197 的上限，故 (8,4) 降位宽、
    # (4,8) 保位宽，两者输出都是 32 位。
    for count, width in ((4, 8), (8, 4)):
        for elem in ("id", "mul", "add", "xor"):
            kernels.append(
                Kernel(name=f"map_{elem}_n{count}w{width}", count=count, width=width,
                       elem=elem, reduce=None, mode="map")
            )
    return tuple(kernels)


KERNELS: tuple[Kernel, ...] = _build_kernels()


# ---------------------------------------------------------------------------
# 激励向量
# ---------------------------------------------------------------------------


def _stable_hash(text: str) -> int:
    """跨进程稳定的字符串哈希。

    不用内置 ``hash()``：CPython 默认对 str 哈希做随机化，``hash("abc")`` 在不同
    进程里并不相同。若用它去播种 RNG，"同一 (kernel, rows, seed) 必得同一组向量"
    这句话就是错的 —— 同一台机器上重跑会得到不同激励。用 CRC32 把这条承诺坐实。
    """
    return zlib.crc32(text.encode("utf-8")) & 0xFFFFFFFF


def make_vectors(kernel: Kernel, rows: int, seed: int) -> list[tuple[list[int], list[int]]]:
    """确定性伪随机激励；同一 (kernel, rows, seed) 必得同一组向量。"""
    rng = random.Random(seed * 100003 + _stable_hash(kernel.name) % 100003)
    limit = 1 << kernel.width
    return [
        ([rng.randrange(limit) for _ in range(kernel.count)],
         [rng.randrange(limit) for _ in range(kernel.count)])
        for _ in range(rows)
    ]


def vectors_to_text(vectors: list[tuple[list[int], list[int]]]) -> str:
    lines = [str(len(vectors))]
    for a, b in vectors:
        lines.append(" ".join(str(v) for v in a))
        lines.append(" ".join(str(v) for v in b))
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# 风险片段（复用已有受控集，避免两处口径漂移）
# ---------------------------------------------------------------------------


def risk_snippets() -> Iterator[tuple[str, str, set[str], str]]:
    """产出 (名称, 源码, 期望风险集合, 分组)。分组：reject / robust / limitation。"""
    from run_parser_experiment import CASES, KNOWN_LIMITATIONS, ROBUSTNESS_EXPECT_CLEAN, ROBUSTNESS_EXPECT_DETECT

    for name, code, expected in CASES:
        if expected:
            yield name, code, expected, "reject"
    for name, code, expected in ROBUSTNESS_EXPECT_DETECT:
        yield name, code, expected, "robust"
    for name, code, expected in ROBUSTNESS_EXPECT_CLEAN:
        yield name, code, expected, "robust"
    for name, code, expected in KNOWN_LIMITATIONS:
        yield name, code, expected, "limitation"
