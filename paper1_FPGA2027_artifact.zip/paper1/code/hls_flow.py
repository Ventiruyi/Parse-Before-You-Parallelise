r"""论文一：从 C 解析约束到 RTL 的生成器（受控子集）。

为什么这里要有"解析约束"这一层
------------------------------
论文一的命题是"**解析结果决定生成决策**"，而不是"让模型自由发挥写到 RTL"。
要让这句话可证伪，就必须存在一个**只有掌握解析结果才能做对**的决策。本实现里
有四个这样的决策点，每一项都会在真实工具链上产生可测后果：

1. **结合律 $\Rightarrow$ 跨通道合并是否保序。** 归约算子若是
   ``acc -= e`` 或 ``acc = e - acc``，加法/减法不满足结合律，把 $N$ 个元素切成
   $L$ 条通道各自累加再合并，得到的值与顺序执行**不同**。因此必须从 C 语句
   里解析出算子与其操作数顺序，才能决定 $L$ 的合法集合。忽略这一点的生成器
   会产出编译通过、综合通过、但**功能错误**的 RTL —— 这一点由 gcc 参考输出
   与 RTL 仿真逐向量比对直接判定。
2. **归约 vs 映射。** 循环体是累加到标量还是写回数组，决定输出是单标量还是
   整块向量，也决定复位初值（``+`` 的初值 0 与 ``min`` 的初值全 1 不同）。
3. **乘法 $\Rightarrow$ 是否占用 DSP。** 元素表达式里出现 ``*`` 才能让综合器
   使用 ``MULT18X18D``，这是可测的资源差异。
4. **不可综合构造 $\Rightarrow$ 是否在消耗后端预算之前就拒绝。**
   动态内存、递归、函数指针、可变长数组由 ``c_parser`` 判定，命中即拒绝生成。

宽度的语义一致性
----------------
所有 kernel 用无符号类型：C 的 ``uint16_t``/``uint32_t`` 与 Verilog 的位向量
在溢出时都是模 $2^n$ 回绕，因此"gcc 输出与 RTL 输出逐向量相等"是一个有定义的
命题。元素位宽 $W$ 与累加位宽 32 的关系在生成时显式零扩展：Verilog 里
``a * b`` 的自决定位宽是操作数最大位宽（不是相加），不做零扩展会静默截断，
所以生成器一律写成 ``({32'b0, a}) * ({32'b0, b})``。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

ELEM_PATTERNS: dict[str, str] = {
    "id": r"^a\[i\]$",
    "mul": r"^\(uint32_t\)\(a\[i\]\)\s*\*\s*\(uint32_t\)\(b\[i\]\)$",
    "add": r"^\(uint32_t\)\(a\[i\]\)\s*\+\s*\(uint32_t\)\(b\[i\]\)$",
    "xor": r"^\(uint32_t\)\(a\[i\]\)\s*\^\s*\(uint32_t\)\(b\[i\]\)$",
}

REDUCE_PATTERNS: list[tuple[str, str]] = [
    ("+", r"^acc\s*\+=\s*e;$"),
    ("max", r"^acc\s*=\s*\(e\)\s*>\s*acc\s*\?\s*\(e\)\s*:\s*acc;$"),
    ("min", r"^acc\s*=\s*\(e\)\s*<\s*acc\s*\?\s*\(e\)\s*:\s*acc;$"),
    ("sub_l", r"^acc\s*-=\s*e;$"),
    ("sub_r", r"^acc\s*=\s*\(e\)\s*-\s*acc;$"),
]

# 每个归约算子在生成时的元数据：初值 + 是否结合 + 跨通道合并写法
REDUCE_META: dict[str, dict[str, Any]] = {
    "+": {"init": "32'd0", "associative": True, "merge": "+"},
    "max": {"init": "32'd0", "associative": True, "merge": "max"},
    "min": {"init": "32'hFFFFFFFF", "associative": True, "merge": "min"},
    "sub_l": {"init": "32'd0", "associative": False, "merge": "-"},
    "sub_r": {"init": "32'd0", "associative": False, "merge": "-"},
}


@dataclass
class Constraint:
    """解析 C 源码得到的生成约束。"""

    mode: str                      # "reduce" | "map"
    count: int                     # 循环上界（元素个数）
    elem: str                      # 元素函数
    reduce_op: str | None          # 归约算子（map 模式为 None）
    associative: bool
    uses_multiplier: bool
    reduce_init: str
    rewrite: bool = False          # sub_l 代数重写：lane 用 + 累加，输出取负
    issues: list[str] = field(default_factory=list)

    def legal_lanes(self, count: int) -> list[int]:
        """该约束下功能正确的通道数集合。"""
        divisors = [lanes for lanes in range(1, count + 1) if count % lanes == 0]
        if self.mode == "map" or self.associative:
            return divisors
        # 非结合归约只能顺序执行：任何 L > 1 都会改变结果
        return [1]


def parse_kernel(source: str) -> Constraint:
    """解析受控子集的 C kernel，抽出生成约束。

    只解析本数据集使用的形态；遇到无法识别的形态抛 ``ValueError``，绝不"猜一个
    默认值继续生成"。
    """
    code = _strip_comments(source)
    count_match = re.search(r"#define\s+N\s+(\d+)", code)
    if not count_match:
        raise ValueError("没有找到 #define N")
    count = int(count_match.group(1))

    loop_match = re.search(r"for\s*\(\s*int\s+i\s*=\s*0\s*;\s*i\s*<\s*N\s*;\s*\+\+i\s*\)", code)
    if not loop_match:
        raise ValueError("没有找到标准形态的 for 循环")

    elem_match = re.search(r"uint32_t\s+e\s*=\s*(.+?);", code)
    map_match = re.search(r"y\[i\]\s*=\s*\(elem_t\)\((.+?)\);", code)
    if elem_match:
        raw_elem = elem_match.group(1).strip()
        mode = "reduce"
    elif map_match:
        raw_elem = map_match.group(1).strip()
        mode = "map"
    else:
        raise ValueError("没有找到元素表达式（既不是归约也不是映射）")

    elem = _match_elem(_normalize_elem(raw_elem, mode))
    uses_multiplier = "*" in raw_elem

    if mode == "map":
        return Constraint(mode=mode, count=count, elem=elem, reduce_op=None,
                          associative=True, uses_multiplier=uses_multiplier,
                          reduce_init="32'd0")

    reduce_op = None
    statements = [line.strip() for line in code.splitlines() if line.strip()]
    for name, pattern in REDUCE_PATTERNS:
        if any(re.match(pattern, line) for line in statements):
            reduce_op = name
            break
    if reduce_op is None:
        raise ValueError("没有识别出归约语句")

    meta = REDUCE_META[reduce_op]
    return Constraint(
        mode=mode, count=count, elem=elem, reduce_op=reduce_op,
        associative=bool(meta["associative"]), uses_multiplier=uses_multiplier,
        reduce_init=str(meta["init"]),
    )


def _strip_width_mask(raw: str) -> str:
    """去掉映射模式下元素表达式末尾的 ``& WMASK``。

    数据集里的 map kernel 写成 ``y[i] = (elem_t)((EXPR) & WMASK);``。这里的
    ``& WMASK`` 与外面的 ``(elem_t)`` 强制转换是**同一件事**：两者都把结果截到
    元素位宽，而 RTL 侧对应的是 ``res{lane}[W-1:0]`` 这一处截断。若不去掉，
    ``_match_elem`` 会把它当成未知元素表达式而拒绝生成 —— 拒绝本身是对的（不能
    静默接受没登记的形态），但这里该做的是把这个冗余掩码显式归一化掉，而不是
    扩大 ELEM_PATTERNS 去承认一个重复的语义。
    """
    return re.sub(r"\s*&\s*WMASK\s*$", "", raw).strip()


def _strip_outer_parens(raw: str) -> str:
    """剥掉恰好包住整个表达式的**一层**多余圆括号。

    map 模板的字符串是 ``(elem_t)((EXPR) & WMASK)``，剥掉 ``& WMASK`` 之后剩下
    ``(EXPR)``，比 reduce 模板（``uint32_t e = EXPR``）多了一层括号。这一层括号
    不改变语义，但会让 ``^a\\[i\\]$`` 这类锚定到端点的模式匹配不上。只剥一层：
    多剥会有把 ``(uint32_t)(a[i])`` 里的 ``(uint32_t)`` 误当成外层括号的风险，
    所以先检查首括号的配对方括号是否正好是最后一个字符。
    """
    text = raw.strip()
    if not (text.startswith("(") and text.endswith(")")):
        return text
    depth = 0
    for index, char in enumerate(text):
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:
                # 首括号在此处闭合；只有当它就是末字符时，这层括号才真正包住整体
                return text[1:-1].strip() if index == len(text) - 1 else text
    return text


def _normalize_elem(raw: str, mode: str) -> str:
    """把两种模式的元素表达式归一化成 ELEM_PATTERNS 里的规范形态。"""
    text = _strip_width_mask(raw) if mode == "map" else raw.strip()
    return _strip_outer_parens(text)


def _match_elem(raw: str) -> str:
    for name, pattern in ELEM_PATTERNS.items():
        if re.match(pattern, raw):
            return name
    raise ValueError(f"未登记的元素表达式：{raw!r}（不要静默当成恒等映射）")


def _strip_comments(code: str) -> str:
    from c_parser import strip_comments_and_strings

    return strip_comments_and_strings(code)


# ---------------------------------------------------------------------------
# RTL 生成
# ---------------------------------------------------------------------------

ELEM_RTL: dict[str, str] = {
    "id": "{{32'b0, sa[{lo} +: {w}]}}",
    "mul": "({{32'b0, sa[{lo} +: {w}]}} * {{32'b0, sb[{lo} +: {w}]}})",
    "add": "({{32'b0, sa[{lo} +: {w}]}} + {{32'b0, sb[{lo} +: {w}]}})",
    "xor": "({{32'b0, sa[{lo} +: {w}]}} ^ {{32'b0, sb[{lo} +: {w}]}})",
}


def _combine(op: str, acc: str, elem: str) -> str:
    """把"当前元素"并入累加量的表达式。

    每个算子都必须显式列出。这里曾经漏掉 ``+``，于是它落到了末尾的 ``sub_r``
    分支上：加法归约被静默生成成 ``elem - acc``（交替减法）。它照样编译、照样
    综合，只是功能错误 —— 正是这类"未覆盖的默认分支"最容易把生成器的错误伪装
    成被测设计的问题。所以末尾不再有兜底分支，未知算子直接报错。
    """
    if op == "+":
        return f"({acc} + {elem})"
    if op == "max":
        return f"({elem} > {acc} ? {elem} : {acc})"
    if op == "min":
        return f"({elem} < {acc} ? {elem} : {acc})"
    if op == "sub_l":
        return f"({acc} - {elem})"
    if op == "sub_r":
        return f"({elem} - {acc})"
    raise ValueError(f"未登记的归约算子：{op!r}（不要用兜底分支猜一个语义）")


def generate_rtl(constraint: Constraint, width: int, lanes: int) -> dict[str, Any]:
    """按约束与通道数生成 RTL；返回源码与仿真所需信息。

    **本函数不拒绝非法通道数**，这是刻意的。对非结合归约（``sub_l``/``sub_r``）
    取 ``L > 1`` 会得到功能错误的 RTL；要让"忽略解析结果的策略会出错"这句话可
    证伪，这种 RTL 就必须真能被生成出来并被真实仿真。合法性只由
    ``Constraint.legal_lanes`` 记录，由**策略层**（``strategy_lanes``）决定要不要
    遵守。若在生成器里拦截非法 L，基线策略就永远产不出错误 RTL，论文的核心断言
    也就无从检验了。
    """
    count = constraint.count
    if count % lanes != 0:
        raise ValueError(f"通道数 {lanes} 不能整除元素个数 {count}")
    cycles = count // lanes
    window = lanes * width
    counter_bits = max(1, (cycles - 1).bit_length())

    ports = [
        "module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);",
        "  input wire clk;",
        "  input wire i_valid;",
        f"  input wire [{count * width - 1}:0] i_a;",
        f"  input wire [{count * width - 1}:0] i_b;",
    ]
    if constraint.mode == "reduce":
        ports.append("  output reg [31:0] o_y;")
    else:
        ports.append(f"  output reg [{count * width - 1}:0] o_y;")
    ports.append("  output reg o_valid;")
    lines = list(ports)
    lines += [
        f"  reg [{counter_bits - 1}:0] cnt;",
        f"  reg [{window - 1}:0] sa, sb;",
    ]

    if constraint.mode == "reduce":
        for lane in range(lanes):
            lines.append(f"  reg [31:0] acc{lane};")
            lines.append(f"  wire [31:0] nxt{lane};")
    else:
        for lane in range(lanes):
            lines.append(f"  wire [31:0] res{lane};")

    # 元素窗口选择：常量基址的 case，避免变基址部分选择带来的额外硬件
    lines.append("  always @* begin")
    lines.append("    case (cnt)")
    for step in range(cycles):
        base = step * window
        lines.append(f"      {counter_bits}'d{step}: begin sa = i_a[{base} +: {window}]; sb = i_b[{base} +: {window}]; end")
    lines.append(f"      default: begin sa = {window}'d0; sb = {window}'d0; end")
    lines.append("    endcase")
    lines.append("  end")

    # part-select 的基址位宽必须覆盖**整窗**内用到的最大偏移 (lanes-1)*width，
    # 而不是元素位宽。曾按 (width-1).bit_length() 取位宽：width=4、lanes=4 时得到
    # 2 位，于是 `2'd4`/`2'd8`/`2'd12` 全部截断成 0，每条通道都读到同一个元素 ——
    # 生成的 RTL 编译、综合都正常，只是每条通道都取第 0 个元素。这类位宽不足
    # 不会报错，只会静默改变语义，因此这里按 window 取位宽。
    index_bits = max(1, (window - 1).bit_length())
    for lane in range(lanes):
        low = lane * width
        elem = ELEM_RTL[constraint.elem].format(lo=f"{index_bits}'d{low}" if low else "0", w=width)
        if constraint.mode == "reduce":
            # 代数重写（sub_l）：lane 内改用普通加法累加，输出统一取负。
            # 语义依据：初值 0 的 sub_l 顺序值 = -Σe mod 2^32，而 -(Σ lane 和)
            # 与之恒等（mod 2^32 加法结合），因此 lane 合法并行。
            lane_op = "+" if (constraint.rewrite and constraint.reduce_op == "sub_l") else constraint.reduce_op
            lines.append(f"  assign nxt{lane} = {_combine(lane_op, f'acc{lane}', elem)};")
        else:
            lines.append(f"  assign res{lane} = {elem};")

    lines.append("  always @(posedge clk) begin")
    if constraint.mode == "reduce":
        resets = " ".join(f"acc{lane} <= {constraint.reduce_init};" for lane in range(lanes))
        lines.append(f"    if (i_valid) begin cnt <= {counter_bits}'d0; o_valid <= 1'b0; {resets} end")
        lines.append("    else begin")
        for lane in range(lanes):
            lines.append(f"      acc{lane} <= nxt{lane};")
        if lanes == 1:
            merged = "nxt0"
        else:
            lane_op = "+" if (constraint.rewrite and constraint.reduce_op == "sub_l") else constraint.reduce_op
            merge_op = REDUCE_META[lane_op]["merge"]
            if merge_op in "+-":
                merged = f" {merge_op} ".join(f"nxt{lane}" for lane in range(lanes))
            else:
                compare = ">" if merge_op == "max" else "<"
                merged = "nxt0"
                for lane in range(1, lanes):
                    merged = f"({merged} {compare} nxt{lane} ? {merged} : nxt{lane})"
        lines.append(f"      if (cnt == {counter_bits}'d{cycles - 1}) begin")
        if constraint.rewrite:
            # rewrite 标志只在 sub_l 的重写变体上置位（replace 后 reduce_op
            # 已是 "+"，不能再拿 reduce_op 当门控——首跑曾因此漏掉取负）。
            lines.append(f"        o_y <= (-({merged}));")
        else:
            lines.append(f"        o_y <= {merged};")
        lines.append("        o_valid <= 1'b1;")
        lines.append(f"        cnt <= {counter_bits}'d0;")
        lines.append("      end else begin")
        lines.append(f"        cnt <= cnt + {counter_bits}'d1;")
        lines.append("        o_valid <= 1'b0;")
        lines.append("      end")
        lines.append("    end")
    else:
        lines.append(f"    if (i_valid) begin cnt <= {counter_bits}'d0; o_valid <= 1'b0; end")
        lines.append("    else begin")
        for lane in range(lanes):
            low = lane * width
            lines.append(f"      o_y[cnt * {window} + {low} +: {width}] <= res{lane}[{width - 1}:0];")
        lines.append(f"      if (cnt == {counter_bits}'d{cycles - 1}) begin o_valid <= 1'b1; cnt <= {counter_bits}'d0; end")
        lines.append("      else begin o_valid <= 1'b0; cnt <= cnt + " + f"{counter_bits}'d1; end")
        lines.append("    end")
    lines.append("  end")
    lines.append("endmodule")
    return {
        "rtl": "\n".join(lines) + "\n",
        "lanes": lanes,
        "cycles": cycles,
        "counter_bits": counter_bits,
    }


def testbench(constraint: Constraint, width: int, vectors: list[tuple[list[int], list[int]]]) -> str:
    """自定时测试台：每行施加一次输入，等 ``o_valid`` 后把 ``o_y`` 打到标准输出。

    测试台里**不含期望值**：它只打印 RTL 实际算出的结果，比对由 Python 用 gcc 的
    输出完成。这样"参考值来自 C 程序执行"这句话是真的，而不是把 gcc 的输出抄进
    测试台再自己比对。
    """
    count = constraint.count
    total = count * width
    rows = len(vectors)
    out_width = 32 if constraint.mode == "reduce" else total
    packed = [(_pack(a, width), _pack(b, width)) for a, b in vectors]

    lines = [
        "`timescale 1ns/1ps",
        "module tb;",
        "  reg clk, i_valid;",
        f"  reg [{total - 1}:0] i_a, i_b;",
        f"  wire [{out_width - 1}:0] o_y;",
        "  wire o_valid;",
    ]
    if constraint.mode == "reduce":
        lines.append("  wire [31:0] o_y_full;")
    lines += [
        f"  reg [{total - 1}:0] va [0:{rows - 1}];",
        f"  reg [{total - 1}:0] vb [0:{rows - 1}];",
        "  integer v, w;",
        "  kernel dut(clk, i_valid, i_a, i_b, o_y, o_valid);",
        "  always #1 clk = ~clk;",
        "  initial begin",
        "    clk = 0; i_valid = 0; i_a = 0; i_b = 0;",
    ]
    for index, (a_packed, b_packed) in enumerate(packed):
        lines.append(f"    va[{index}] = {total}'h{a_packed:x};")
        lines.append(f"    vb[{index}] = {total}'h{b_packed:x};")
    lines += [
        f"    for (v = 0; v < {rows}; v = v + 1) begin",
        "      i_a = va[v]; i_b = vb[v];",
        "      i_valid = 1;",
        "      @(negedge clk);",
        "      i_valid = 0;",
        "      w = 0;",
        f"      while (o_valid !== 1'b1 && w < {count + 4}) begin",
        "        @(negedge clk); w = w + 1;",
        "      end",
        "      if (o_valid === 1'b1) $display(\"OUT %0d %h\", v, o_y);",
        "      else $display(\"TIMEOUT %0d\", v);",
        "    end",
        "    $finish;",
        "  end",
        "endmodule",
    ]
    return "\n".join(lines) + "\n"


def _pack(values: list[int], width: int) -> int:
    """把元素列表拼成宽位向量（低位在前），与生成器的窗口切分一致。

    真正的实现在 ``hls_dataset.pack_fields``：测试台与参考值打包必须共用同一份
    约定，否则"逐值比对"会在两侧都自认为正确的情况下给出错误结论。
    """
    from hls_dataset import pack_fields

    return pack_fields(values, width)
