#!/usr/bin/env python3
# 按正文首次引用顺序重排手工 thebibliography（paper1/paper3）
import re
import sys

for p in ('paper1', 'paper3'):
    path = f'{p}/submission/main.tex'
    s = open(path, encoding='utf-8').read()
    head, bib_env = s.split(r'\begin{thebibliography}')
    bib_env = r'\begin{thebibliography}' + bib_env
    tail_start = bib_env.rfind(r'\end{thebibliography}')
    tail = bib_env[tail_start:]
    bib_body = bib_env[:tail_start]

    # 首次引用顺序
    body = s.split(r'\begin{thebibliography}')[0]
    first = {}
    for m in re.finditer(r'\\cite\{([^}]*)\}', body):
        for k in m.group(1).split(','):
            k = k.strip()
            if k and k not in first:
                first[k] = len(first)
    order_first = [k for k, _ in sorted(first.items(), key=lambda x: x[1])]

    # 切分 bibitem 块
    pre = bib_body[:bib_body.find(r'\bibitem')]
    blocks = re.split(r'(?=\\bibitem)', bib_body[bib_body.find(r'\bibitem'):])
    blocks = [b for b in blocks if b.strip()]
    keys = [re.match(r'\\bibitem\{(\w+)\}', b).group(1) for b in blocks]

    if sorted(keys) != sorted(order_first):
        print(f'{p}: 集合不一致，跳过（需人工核对）')
        continue
    by_key = dict(zip(keys, blocks))
    new_body = pre + ''.join(by_key[k] for k in order_first)
    new_s = head + new_body + tail
    open(path, 'w', encoding='utf-8', newline='').write(new_s)
    print(f'{p}: 文献表已按首次引用顺序重排（{len(keys)} 条）')
