"""受控初始化错误实验：用独立 Python 参考计算错误初值的失败向量。"""
from __future__ import annotations
import json, random
from pathlib import Path

def run(op, values, init):
    acc = init
    for x in values:
        if op == "max":
            acc = max(acc, x)
        elif op == "min":
            acc = min(acc, x)
    return acc

rng = random.Random(2027)
rows = []
for op, good in (("max", 0), ("min", 255)):
    vectors = [[rng.randrange(256) for _ in range(4)] for _ in range(64)]
    bad_init = 0
    failures = sum(run(op, v, bad_init) != run(op, v, good) for v in vectors)
    rows.append({"operator": op, "vectors": len(vectors), "correct_init": good,
                 "wrong_init": bad_init, "failures": failures,
                 "failure_rate": round(failures / len(vectors), 4)})
out = Path(__file__).resolve().parents[1] / "results" / "init_controlled.json"
out.write_text(json.dumps({"experiment": "initialization_controlled", "rows": rows}, indent=2), encoding="utf-8")
print(json.dumps(rows, ensure_ascii=False))
