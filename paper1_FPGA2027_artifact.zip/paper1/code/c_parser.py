"""C/HLS 可综合性静态检查器（v2）。

v2 相对 v1 的修复（每条对应论文一审阅报告的一项发现）：

1. **VLA 规则**：v1 的 ``\\[\\s*[A-Za-z_]\\w*\\s*\\]`` 会命中任意 ``a[i]``
   数组访问（safe_loop 误报根因）。v2 只在**声明位置**（类型关键字
   + 标识符 + 非常量下标）报 VLA，语句中的 ``a[i] = ...`` 不再误报。
2. **severity 分级**：v1 硬编码全部 ``"error"`` 且任何 issue 都使
   ``synthesizable=False``，与正文 §3.2 的分级描述不符。v2 按类型分级：
   结构性错误（error）→ 不可综合；边界问题（warning）→ 可综合但要求把
   大小提升为编译期参数。
3. **free 拆分**：``free`` 从 dynamic_memory 拆出为
   dynamic_memory_release（warning）：释放调用本身不是综合风险点，
   真正的风险是"存在过动态分配"。
4. **递归扫描**：v1 的正则用 ``[^{}]*`` 匹配函数体，嵌套花括号（if/for
   块）即失效。v2 用平衡花括号扫描函数体，嵌套块中的递归调用可检出。
5. **预处理**：先剥离注释与字符串/字符字面量（保持行号），避免注释里
   的 ``malloc`` 和字符串字面量误报。

已知限制（在论文中作为鲁棒性边界公开，不在受控集内掩饰）：
- 宏别名（``#define ALLOC malloc``）不可见；
- typedef 自定义类型声明的 VLA（``myint a[n]``）不识别；
- 函数指针正则只覆盖常见声明形态。
"""
from __future__ import annotations

import re
from typing import Any

_C_KEYWORDS = {
    "while", "for", "if", "else", "switch", "case", "default", "sizeof",
    "return", "break", "continue", "goto", "do", "typedef", "struct",
    "union", "enum", "static", "extern", "register", "auto", "inline",
}

_TYPE_TOKEN = (
    r"\b(?:(?:unsigned|signed|const|volatile|long|short)\s+)*"
    r"(?:int|char|float|double|size_t|ssize_t|void|"
    r"int8_t|int16_t|int32_t|int64_t|uint8_t|uint16_t|uint32_t|uint64_t)\b"
)

ALLOC_RE = re.compile(r"\b(?:malloc|calloc|realloc)\s*\(")
RELEASE_RE = re.compile(r"\bfree\s*\(")
FUNC_PTR_RE = re.compile(r"\(\s*\*\s*\w+\s*\)\s*\(")
VLA_DECL_RE = re.compile(_TYPE_TOKEN + r"\s+(?:\*?\s*\w+\s*)?\[\s*([A-Za-z_]\w*)\s*\]")
FUNC_HEADER_RE = re.compile(r"\b([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{")


def strip_comments_and_strings(code: str) -> str:
    """把注释和字符串/字符字面量内容替换为空格，保留换行以维持行号。"""
    out: list[str] = []
    i, n = 0, len(code)
    while i < n:
        two = code[i : i + 2]
        if two == "//":
            j = code.find("\n", i)
            j = n if j == -1 else j
            out.append(" " * (j - i))
            i = j
        elif two == "/*":
            j = code.find("*/", i + 2)
            j = n if j == -1 else j + 2
            out.append("".join(c if c == "\n" else " " for c in code[i:j]))
            i = j
        elif code[i] in "\"'":
            quote = code[i]
            j = i + 1
            while j < n and code[j] != quote:
                if code[j] == "\\":
                    j += 1
                j += 1
            j = min(j + 1, n)
            out.append("".join(c if c == "\n" else " " for c in code[i:j]))
            i = j
        else:
            out.append(code[i])
            i += 1
    return "".join(out)


def _line_of(code: str, position: int) -> int:
    return code.count("\n", 0, position) + 1


class CHLSParser:
    """静态可综合性检查器。输出契约：``{ast, issues, synthesizable}``。"""

    ISSUE_SEVERITY = {
        "dynamic_memory": "error",
        "function_pointer": "error",
        "recursion": "error",
        "variable_length_array": "warning",
        "dynamic_memory_release": "warning",
    }

    def parse(self, c_code: str) -> dict[str, Any]:
        if not isinstance(c_code, str):
            raise TypeError("c_code 必须是字符串")
        code = strip_comments_and_strings(c_code)
        issues: list[dict[str, Any]] = []
        issues += self._scan(code, ALLOC_RE, "dynamic_memory")
        issues += self._scan(code, RELEASE_RE, "dynamic_memory_release")
        issues += self._scan(code, FUNC_PTR_RE, "function_pointer")
        issues += self._scan(code, VLA_DECL_RE, "variable_length_array")
        issues += self._find_recursion(code)
        issues.sort(key=lambda item: (item["line"], item["type"]))
        synthesizable = not any(item["severity"] == "error" for item in issues)
        return {"ast": None, "issues": issues, "synthesizable": synthesizable}

    def _scan(self, code: str, pattern: re.Pattern[str], issue_type: str) -> list[dict[str, Any]]:
        return [
            {
                "type": issue_type,
                "line": _line_of(code, match.start()),
                "severity": self.ISSUE_SEVERITY[issue_type],
            }
            for match in pattern.finditer(code)
        ]

    def _find_recursion(self, code: str) -> list[dict[str, Any]]:
        """平衡花括号扫描函数定义体，体内出现对自身的调用即报递归。"""
        issues: list[dict[str, Any]] = []
        for match in FUNC_HEADER_RE.finditer(code):
            name = match.group(1)
            if name in _C_KEYWORDS:
                continue
            depth = 0
            i = match.end() - 1
            n = len(code)
            while i < n:
                if code[i] == "{":
                    depth += 1
                elif code[i] == "}":
                    depth -= 1
                    if depth == 0:
                        break
                i += 1
            body = code[match.end() : i]
            if re.search(rf"\b{name}\s*\(", body):
                issues.append(
                    {
                        "type": "recursion",
                        "line": _line_of(code, match.start()),
                        "severity": self.ISSUE_SEVERITY["recursion"],
                    }
                )
        return issues
