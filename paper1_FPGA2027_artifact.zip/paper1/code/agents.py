"""不依赖外部 LLM 的多 Agent HLS 流程骨架。"""
from __future__ import annotations

from typing import Any, Protocol

from c_parser import CHLSParser


class LLMBackend(Protocol):
    def generate(self, prompt: str) -> str: ...


class DeterministicBackend:
    """用于单测和离线开发的占位后端，不声称等价于 LLM。"""

    def generate(self, prompt: str) -> str:
        return "// generated candidate\n" + prompt


class MultiAgentFramework:
    def __init__(self, llm_backend: LLMBackend | None = None) -> None:
        self.llm = llm_backend or DeterministicBackend()
        self.parser = CHLSParser()

    def transform(self, c_code: str, max_iterations: int = 3) -> dict[str, Any]:
        parse_result = self.parser.parse(c_code)
        strategy = "direct_convert" if parse_result["synthesizable"] else "rewrite_issues"
        candidate = self.llm.generate(f"strategy={strategy}\n{c_code}")
        history = [{"iteration": 0, "passed": bool(candidate.strip()), "issues": parse_result["issues"]}]
        return {"hls_code": candidate, "parse": parse_result, "strategy": strategy, "history": history, "passed": history[-1]["passed"]}
