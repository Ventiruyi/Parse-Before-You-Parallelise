import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agents import MultiAgentFramework
from c_parser import CHLSParser


def test_parser_flags_dynamic_memory_and_vla():
    result = CHLSParser().parse("void f(int n) { int a[n]; int *p = malloc(4); }")
    assert not result["synthesizable"]
    assert {item["type"] for item in result["issues"]} >= {"dynamic_memory", "variable_length_array"}


def test_framework_returns_trace():
    result = MultiAgentFramework().transform("int f(int x) { return x + 1; }")
    assert result["passed"]
    assert result["history"]
