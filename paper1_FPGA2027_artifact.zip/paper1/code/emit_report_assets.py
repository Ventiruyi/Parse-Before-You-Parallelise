r"""从 paper1/results/** 生成论文所需的一切数字、表格与图，写入 submission/。

为什么要有这个脚本
------------------
投稿版正文里不允许出现手抄的数字。本脚本把 results 目录当作唯一事实来源，每次
重新生成 numbers.tex、tables/*.tex 与 figs/*.tex；正文只引用宏与 \input。

比"不手抄"更强的一条：**本脚本会校验论文的核心断言**。论文要说的几件事
（"忽略解析结果的策略在非结合归约上会产出功能错误的 RTL"、"按约束生成的策略
在这些 kernel 上功能全对"、"没有一条功能错误的 RTL 蒙混过关"、"模型与 gcc 参考
逐向量一致"）在下面都写成了断言。数据一旦不支持某条断言，脚本直接报错退出，
而不是继续生成一份看起来完整、结论却站不住的正文。

数据来源（缺任何一项都直接报错退出，绝不静默用默认值）
-----------------------------------------------------
- results/hls_generation/hls_generation.json   真实 gcc 参考 + Icarus 仿真 +
  ECP5（Yosys/nextpnr/ecppack）综合；必须 complete == true
- results/hls_generation/runs.csv              每条 (kernel, 策略, 种子) 的记录
- results/parser_controlled/parser_experiment.json  受控片段上的风险识别结果

用法::

    python paper1/code/emit_report_assets.py
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

STRATEGY_LABEL = {
    "rolled": "rolled",
    "full": "unroll-all",
    "budget": "budget-only",
    "random": "random",
    "constraint": "parse-driven",
}
STRATEGY_ORDER = ("rolled", "full", "budget", "random", "constraint")


# escape() 有意产生的转义序列；宏值里只允许出现这几个反斜杠。
ALLOWED_ESCAPES = ("\\%", "\\&", "\\_", "\\#")


def safe_text(text: str) -> str:
    """把来自工具/结果文件的**原始文本**清成可放进 LaTeX 的片段。

    反斜杠是 LaTeX 的控制序列起始符：从工具输出里原样搬来的 Windows 路径会静默
    变成一串未定义控制序列，而报错位置在几十个宏之外。这里先把反斜杠替换掉、把
    连续空白压平，再交给 ``escape`` 处理 ``%&_#``。顺序不能反：若先 escape 再清理
    反斜杠，``\\_`` 会被打回成 ``/_``。
    """
    cleaned = str(text).replace("\\", "/")
    return " ".join(cleaned.split())


def fmt(value: float | None, digits: int = 1) -> str:
    if value is None:
        raise ValueError("需要格式化 None")
    return f"{value:.{digits}f}"


def text(value: str) -> str:
    """外部文本 -> 可安全放进宏的 LaTeX 片段（先清理反斜杠，再转义特殊字符）。"""
    return escape(safe_text(value))


def load_json(path: Path) -> Any:
    if not path.exists():
        raise SystemExit(f"缺少结果文件：{path}（请先运行对应的实验脚本，不要用手工数字顶替）")
    return json.loads(path.read_text(encoding="utf-8"))


def escape(text: str) -> str:
    out = []
    for char in str(text):
        if char == "%":
            out.append("\\%")
        elif char == "&":
            out.append("\\&")
        elif char == "_":
            out.append("\\_")
        elif char == "#":
            out.append("\\#")
        else:
            out.append(char)
    return "".join(out)


def short_label(name: str) -> str:
    """把 kernel 名压成表格里放得下的短标签，例如 sub-l/id/n8。"""
    compact = name.replace("reduce_", "").replace("map_", "map/")
    return compact.replace("_", "/")


# ---------------------------------------------------------------------------
# 数据装载与自检
# ---------------------------------------------------------------------------


class Data:
    def __init__(self, root: Path) -> None:
        self.generation = load_json(root / "paper1/results/hls_generation/hls_generation.json")
        self.parser = load_json(root / "paper1/results/parser_controlled/parser_experiment.json")
        self.init_control = load_json(root / "paper1/results/init_controlled.json")
        self.nonzero_init = load_json(root / "paper1/results/nonzero_init_rtl/summary.json")
        self.polybench_admission = load_json(root / "paper1/results/polybench_admission.json")
        self.polybench_concrete = load_json(root / "paper1/results/polybench_concrete/polybench_concrete.json")
        self.exhaustive_n3 = load_json(root / "paper1/results/exhaustive_n3/summary.json")
        # 被中断的重跑会留下 complete=false 的占位清单；此时任何数字都不可信。
        if self.generation.get("complete") is not True:
            raise SystemExit(
                "hls_generation.json 的 complete 不为 true：上一轮实验被中断，"
                "其中的数字不可用。请重跑 run_hls_experiment.py。"
            )
        self.kernels = self.generation["kernels"]
        self.runs = self.generation["runs"]
        self.summary = self.generation["summary"]
        self.risky = self.generation["risk_snippets"]
        self.by_strategy = self.summary["by_strategy"]
        self.assoc = [k for k in self.kernels if k["associative"]]
        self.nonassoc = [k for k in self.kernels if not k["associative"]]
        self._check()

    # -- 断言：论文的核心结论必须在数据里成立 -------------------------------

    def _check(self) -> None:
        s = self.summary
        problems: list[str] = []

        # 1) 参考值与独立模型必须逐 kernel 一致，否则"参考值可信"这条地基不成立
        if s["model_gcc_agreement"] != s["kernels"]:
            problems.append(
                f"gcc 参考与 Python 模型一致数 {s['model_gcc_agreement']} != kernel 数 {s['kernels']}"
            )

        # 2) 按约束生成的策略必须全部功能正确
        constraint = self.by_strategy["constraint"]
        if constraint["rate"] != 1.0:
            problems.append(f"parse-driven 策略功能通过率 {constraint['rate']} != 1.0")
        if constraint["illegal_lane_runs"]:
            problems.append(f"parse-driven 策略出现 {constraint['illegal_lane_runs']} 条非法通道数运行")

        # 3) 两个不看算子的策略（unroll-all 与 budget-only）必须都在非结合归约上出错，
        #    且出错位置正好是非结合归约的 kernel 集合。budget-only 与 parse-driven
        #    只差"是否读算子"这一位，二者结果的差异因此可以干净地归因到解析。
        expect_fail = sorted(k["kernel"] for k in self.nonassoc if k["mode"] == "reduce")
        for name in ("full", "budget"):
            row = self.by_strategy[name]
            if row["rate"] is None or row["rate"] >= 1.0:
                problems.append(f"{name} 策略通过率 {row['rate']}，未能证伪其正确性")
            failed = sorted(
                {
                    r["kernel"]
                    for r in self.runs
                    if r["strategy"] == name and not r["identical_to_seed0"] and not r["functional_pass"]
                }
            )
            if failed != expect_fail:
                problems.append(f"{name} 出错的 kernel 集合与预期不符：{failed} != {expect_fail}")

        # 5) 不许有"非法通道数却功能通过"的漏网之鱼（否则核心断言被证伪）
        silent = sum(
            (self.by_strategy[name].get("illegal_but_passed") or 0) for name in STRATEGY_ORDER
        )
        if silent:
            problems.append(f"存在 {silent} 条非法通道数却功能通过的运行")

        # 6) 干净片段不得被误报
        if s["risk_false_reject"]:
            problems.append(f"干净片段被误报 {s['risk_false_reject']} 例")

        # 7) 风险片段里除已知限制外必须精确匹配
        limitations = sum(1 for r in self.risky if r["group"] == "limitation")
        if s["risk_exact"] != s["risk_snippets"] - limitations:
            problems.append(
                f"风险片段精确匹配 {s['risk_exact']} != 片段总数 {s['risk_snippets']} - 已知限制 {limitations}"
            )

        # 8) 片段集构成必须自洽：exact = reject 类 + robustness，limitation 为其余
        reject_n = sum(1 for r in self.risky if r["group"] == "reject")
        robust_total = self.parser["robustness"]["total"]
        if len(self.risky) != s["risk_snippets"]:
            problems.append(f"risk_snippets 行数 {len(self.risky)} != 汇总数 {s['risk_snippets']}")
        if reject_n + robust_total != s["risk_exact"]:
            problems.append(
                f"片段集构成不平：reject {reject_n} + robustness {robust_total} "
                f"!= 精确匹配 {s['risk_exact']}"
            )

        if problems:
            raise SystemExit("核心断言在数据里不成立，拒绝生成正文资产：\n  - " + "\n  - ".join(problems))

    # -- 便于取数的辅助 -----------------------------------------------------

    def seed0(self, kernel: str, strategy: str) -> dict[str, Any]:
        for r in self.runs:
            if r["kernel"] == kernel and r["strategy"] == strategy and r["seed"] == 0:
                return r
        raise SystemExit(f"缺少 {kernel} / {strategy} / seed0 的运行记录")

    def seed0_runs(self, strategy: str, kernels: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return [self.seed0(k["kernel"], strategy) for k in kernels]

    def mean_cycles(self, strategy: str, kernels: list[dict[str, Any]]) -> float:
        """只取 0 号种子，使各策略在同一批 kernel 上成对比较，不被多种子拉偏。"""
        rows = self.seed0_runs(strategy, kernels)
        return sum(r["cycles"] for r in rows) / len(rows)

    def mean_lanes(self, strategy: str, kernels: list[dict[str, Any]]) -> float:
        rows = self.seed0_runs(strategy, kernels)
        return sum(r["lanes"] for r in rows) / len(rows)


# ---------------------------------------------------------------------------
# 宏
# ---------------------------------------------------------------------------


class Macros:
    def __init__(self) -> None:
        self.values: dict[str, str] = {}

    def set(self, name: str, value: Any) -> None:
        self.values[name] = str(value)

    def render(self) -> str:
        # TeX 控制序列只能由字母组成：名字里出现数字时 \newcommand{\Foo81} 实际定义
        # 的是 \Foo，"81" 变成正文文字，第二个同名宏还会报 already defined。
        bad = sorted(name for name in self.values if not name.isalpha())
        if bad:
            raise SystemExit(f"宏名只能包含字母，以下名称非法：{bad}")
        # 值里只允许出现 escape() 有意产生的转义；其余反斜杠一律视为脏数据。
        # 从工具输出里原样搬来的 Windows 路径属于后者：它会静默变成一串未定义控制
        # 序列，而报错位置在几十个宏之外，极难定位。所以在生成期就拦住。
        leftover = []
        for name, value in self.values.items():
            remaining = value
            for token in ALLOWED_ESCAPES:
                remaining = remaining.replace(token, "")
            if "\\" in remaining:
                leftover.append(name)
        if leftover:
            raise SystemExit(f"以下宏的值含非法反斜杠，会破坏 LaTeX：{sorted(leftover)}")
        lines = ["% 由 emit_report_assets.py 生成；请勿手工编辑。"]
        for name in sorted(self.values):
            lines.append(f"\\newcommand{{\\{name}}}{{{self.values[name]}}}")
        return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# 表
# ---------------------------------------------------------------------------


def table_parse(data: Data) -> str:
    p = data.parser
    lines = [
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Risk detection on controlled fragment sets. The risk benchmark",
        "comprises \\POneRiskSnippets{} snippets: \\POneRiskRejectN{} reject-class,",
        "\\POneRobust{} robustness, and \\POneLimitations{} documented limitations;",
        "the class rows decompose the scored snippets by expected label (a",
        "multi-label snippet counts in each row). \\emph{FP} counts clean fragments",
        "wrongly flagged; none occur. The limitations are counted but not scored.",
        "The core \\POneCoreExact{}/\\POneCoreExact{} row is the separate",
        "parse-constraint fragment set of \\S\\ref{sec:method}.}",
        "\\label{tab:parse}",
        "\\scriptsize",
        "\\begin{tabular}{lrrrr}",
        "\\toprule",
        "Risk class & TP & FP & FN & $R$ \\\\",
        "\\midrule",
    ]
    for label in sorted(p["per_label"]):
        row = p["per_label"][label]
        # escape() 已经负责把下划线转成 \_；这里不能再手工替一遍，否则得到
        # \_ 的双重转义（\_ 会原样打出反斜杠）。
        lines.append(
            f"\\texttt{{{escape(label)}}} & {row['tp']} & "
            f"{row['fp']} & {row['fn']} & {fmt(row['recall'] * 100, 0)} \\\\"
        )
    lines += [
        "\\midrule",
        f"Core fragments (exact) & \\multicolumn{{4}}{{l}}{{{int(p['core_exact_match'] * p['core_dataset_size'])}"
        f"/{p['core_dataset_size']}}} \\\\",
        f"Robustness fragments & \\multicolumn{{4}}{{l}}{{{p['robustness']['passed']}"
        f"/{p['robustness']['total']}}} \\\\",
        f"Known limitations & \\multicolumn{{4}}{{l}}{{\\POneLimitations{{}}}} \\\\",
        "\\bottomrule",
        "\\end{tabular}",
        "\\end{table}",
        "",
    ]
    return "\n".join(lines)


def table_strategy(data: Data) -> str:
    lines = [
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Generation strategies. Byte-identical deterministic repeats across",
        "seeds are deduplicated before evaluation; $n$ counts distinct designs,",
        "\\POneRunsTotal{} over the five policies. \\emph{pass}: distinct RTL whose",
        "outputs match the gcc reference on every vector; \\emph{ill.\\ $L$}: runs that",
        "chose a lane count for which the reduction is not order-preserving;",
        "\\emph{silent}: illegal-lane runs whose outputs nevertheless match the",
        "reference on every vector; there are none, so no order-violating design is",
        "accidentally correct, and only the functional comparison catches one.",
        "$\\bar{L}$ and $\\bar{c}$ are means",
        "over associative kernels at seed~0 (lanes, cycles per vector); the rolled",
        "row's 6.00 cycles averages the four associative kernels (4 cycles at size 4,",
        "8 at size 8), since a rolled design runs one cycle per element.}",
        "\\label{tab:strategy}",
        "\\scriptsize",
        "\\begin{tabular}{lrrrrrrr}",
        "\\toprule",
        "Strategy & $n$ & pass & rate & ill.\\ $L$ & silent & $\\bar{L}$ & $\\bar{c}$ \\\\",
        "\\midrule",
    ]
    for name in STRATEGY_ORDER:
        row = data.by_strategy[name]
        rate = "--" if row["rate"] is None else fmt(row["rate"] * 100, 1)
        lines.append(
            f"{STRATEGY_LABEL[name]} & {row['evaluated']} & {row['passed']} & {rate} & "
            f"{row['illegal_lane_runs']} & {row['illegal_but_passed']} & "
            f"{fmt(data.mean_lanes(name, data.assoc), 2)} & {fmt(data.mean_cycles(name, data.assoc), 2)} \\\\"
        )
    lines += [
        "\\bottomrule",
        "\\end{tabular}",
        "\\end{table}",
        "",
    ]
    return "\n".join(lines)


def table_nonassoc(data: Data) -> str:
    lines = [
        "\\begin{table}[t]",
        "\\centering",
        "\\caption{Non-associative reductions at seed~0. Each cell gives the lane count the",
        "policy chose and whether the resulting RTL matches the gcc reference",
        "($\\surd$) or not ($\\times$). Any $L>1$ changes the value, so only $L=1$ is",
        "correct; a policy that does not read the operator cannot know this. The",
        "budget-only and parse-driven columns use the same budget and the same",
        "largest-divisor rule, so the only difference between them is whether the parsed",
        "operator was consulted.}",
        "\\label{tab:nonassoc}",
        "\\scriptsize",
        "\\begin{tabular}{llrrrrr}",
        "\\toprule",
        "Kernel & Op & rolled & unroll-all & budget-only & random & parse-driven \\\\",
        "\\midrule",
    ]
    for kernel in data.nonassoc:
        name = kernel["kernel"]
        cells = []
        for strategy in STRATEGY_ORDER:
            run = data.seed0(name, strategy)
            mark = "$\\surd$" if run["functional_pass"] else "$\\times$"
            cells.append(f"{run['lanes']}{mark}")
        lines.append(
            f"\\texttt{{{escape(short_label(name))}}} & \\texttt{{{escape(kernel['reduce_op'])}}} & "
            + " & ".join(cells) + " \\\\"
        )
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(lines)


def table_ppa(data: Data) -> str:
    rows = [r for r in data.runs if r.get("status") == "ok" and r["strategy"] == "constraint"]
    lines = [
        "\\begin{table*}[t]",
        "\\centering",
        "\\caption{Measured cost of the parse-driven RTL (seed~0) on LFE5U-25F, "
        "CABGA256, speed grade 6. $L$: lanes; $c$: cycles per input vector; "
        "$t$: $c \\times 1000 / f_{\\max}$ in ns. \\emph{DSP} counts MULT18X18D blocks, "
        "instantiated only when the element expression contains a multiplication.}",
        "\\label{tab:ppa}",
        "\\scriptsize",
        "\\begin{tabular}{lrrrrrrr}",
        "\\toprule",
        "Kernel & $L$ & $c$ & LUT & FF & DSP & $f_{\\max}$ (MHz) & $t$ (ns) \\\\",
        "\\midrule",
    ]
    for r in rows:
        lines.append(
            f"\\texttt{{{escape(short_label(r['kernel']))}}} & {r['lanes']} & {r['cycles']} & "
            f"{r.get('lut', '--')} & {r.get('ff', '--')} & {r.get('dsp', '--')} & "
            f"{fmt(r.get('fmax_mhz'), 1) if r.get('fmax_mhz') else '--'} & "
            f"{fmt(r.get('time_per_vector_ns'), 1) if r.get('time_per_vector_ns') else '--'} \\\\"
        )
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{table*}", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 图
# ---------------------------------------------------------------------------


def _bars(rows: list[tuple[str, float]], y_max: float, y_label: str, fmt_value: str) -> str:
    """生成一个朴素的竖直条形图（黑白、无颜色），四条柱。"""
    width_cm = 6.4
    gap = 0.30
    bar_w = 0.62
    height = 2.5
    n = len(rows)
    total_w = n * bar_w + (n + 1) * gap
    x_scale = width_cm / total_w
    y_scale = height / (y_max * 1.18)
    lines = [
        "% 由 emit_report_assets.py 生成。",
        "\\begin{tikzpicture}[x=%.4fcm,y=%.4fcm]" % (x_scale, y_scale),
        # 纵轴与刻度
        f"  \\draw[->,line width=0.6pt] (0,0) -- ({total_w:.3f},0);",
        f"  \\draw[->,line width=0.6pt] (0,0) -- (0,{y_max * 1.18:.2f}) "
        f"node[above,font=\\scriptsize] {{{y_label}}};",
        f"  \\draw (0,{y_max:.2f}) -- (-0.12,{y_max:.2f}) "
        f"node[left,font=\\scriptsize] {{{fmt_value % y_max}}};",
        f"  \\draw[black!20] (0,{y_max:.2f}) -- ({total_w:.3f},{y_max:.2f});",
    ]
    x = gap
    for label, value in rows:
        cx = x + bar_w / 2
        if value > 0:
            lines.append(
                f"  \\fill[black!70] ({x:.3f},0) rectangle ({x + bar_w:.3f},{value:.3f});"
            )
        value_text = fmt_value % value
        # 数值标签上移一点点：柱顶正好落在网格线上时（例如 6.0 与 6.0 刻度重合）
        # 标签会压在线上，看起来像被划掉。
        lines.append(
            f"  \\node[anchor=south,font=\\scriptsize,yshift=1.2pt] at "
            f"({cx:.3f},{max(value, 0.0):.3f}) {{{value_text}}};"
        )
        lines.append(
            f"  \\node[anchor=north,font=\\scriptsize,align=center] at ({cx:.3f},-0.10) {{{label}}};"
        )
        x += bar_w + gap
    lines.append(
        f"  \\useasboundingbox (-0.95,-0.85) rectangle ({total_w + 0.15:.3f},{y_max * 1.25:.2f});"
    )
    lines += ["\\end{tikzpicture}", ""]
    return "\n".join(lines)


def fig_rates(data: Data) -> str:
    """非结合归约上的功能通过率：不看算子的策略在此崩掉。"""
    rows = []
    for name in STRATEGY_ORDER:
        subset = [
            r
            for r in data.runs
            if r["strategy"] == name
            and not r["identical_to_seed0"]
            and not next(k for k in data.kernels if k["kernel"] == r["kernel"])["associative"]
        ]
        rate = 100.0 * sum(1 for r in subset if r["functional_pass"]) / len(subset) if subset else 0.0
        rows.append((STRATEGY_LABEL[name].replace("-", "-\\allowbreak "), rate))
    return _bars(rows, 100.0, "pass (\\%)", "%.0f")


def fig_latency(data: Data) -> str:
    """结合归约上的每向量周期数：全展开最快、完全折叠最慢。"""
    rows = [
        (STRATEGY_LABEL[name].replace("-", "-\\allowbreak "), data.mean_cycles(name, data.assoc))
        for name in STRATEGY_ORDER
    ]
    y_max = max(value for _, value in rows) * 1.0
    return _bars(rows, y_max, "$\\bar{c}$", "%.1f")


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


def build(root: Path, submission: Path) -> None:
    data = Data(root)
    macros = Macros()
    s = data.summary
    p = data.parser

    # --- 工具链与数据集 -------------------------------------------------
    macros.set("POneKernels", s["kernels"])
    macros.set("POneReduce", s["reduce_kernels"])
    macros.set("POneMap", s["map_kernels"])
    macros.set("POneNonAssoc", s["nonassociative_kernels"])
    macros.set("POneMultiplier", s["multiplier_kernels"])
    macros.set("POneRows", data.generation["design"]["vector_rows"])
    macros.set("POneSeeds", data.generation["design"]["seeds"])
    macros.set("POneLaneBudget", data.generation["design"]["lane_budget"])
    macros.set("POneVectors", s["kernels"] * data.generation["design"]["vector_rows"])
    macros.set("POneGccRuns", s["kernels"])
    macros.set("POneModelAgree", s["model_gcc_agreement"])
    macros.set("POneRunsTotal", s["runs_total"])
    macros.set("POneRunsEval", s["runs_evaluated"])
    macros.set("POneDspKernels", s["dsp_used_kernels"])
    macros.set("POneSimRuns", s["runs_evaluated"])
    macros.set("POneToolchain", text(data.generation["backend"]["flow"]))
    macros.set("POneMapper", text(data.generation["backend"]["mapper"]))
    macros.set("POneDevice", text(data.generation["backend"]["device"]))
    macros.set("POneIverilog", text(data.generation["backend"]["simulator"]))

    # --- 策略对比 -------------------------------------------------------
    for name in STRATEGY_ORDER:
        row = data.by_strategy[name]
        label = "".join(part.capitalize() for part in name.split("_"))
        macros.set(f"POneRate{label}", fmt(row["rate"] * 100, 1) if row["rate"] is not None else "--")
        macros.set(f"POnePass{label}", row["passed"])
        macros.set(f"POneN{label}", row["evaluated"])
        macros.set(f"POneIllegal{label}", row["illegal_lane_runs"])
        macros.set(f"POneSilent{label}", row["illegal_but_passed"])
        macros.set(f"POneLanes{label}", fmt(data.mean_lanes(name, data.assoc), 2))
        macros.set(f"POneCycles{label}", fmt(data.mean_cycles(name, data.assoc), 2))
    macros.set("POneSilentTotal", sum(
        (data.by_strategy[name].get("illegal_but_passed") or 0) for name in STRATEGY_ORDER
    ))

    # 折叠 vs 按约束：结合归约上的周期数之比（成对、同 kernel）
    rolled_c = data.mean_cycles("rolled", data.assoc)
    driven_c = data.mean_cycles("constraint", data.assoc)
    if driven_c <= 0:
        raise SystemExit("parse-driven 的平均周期数非正，无法给出加速比")
    macros.set("POneCycleRatio", fmt(rolled_c / driven_c, 2))
    macros.set("POneLanesRatio", fmt(
        data.mean_lanes("constraint", data.assoc) / data.mean_lanes("rolled", data.assoc), 2
    ))

    # 受控对比（budget-only vs parse-driven）：
    # - 在结合归约上两者应当**完全一致**（同样的预算、同样的取最大因子规则），
    #   也就是"不读算子在这个子集上不付出任何代价"；
    # - 在非结合归约上，parse-driven 必须退到 L=1 才能保住正确性，代价是周期数
    #   变多。这个代价要如实写出来，不能只说"我们的策略全对"就完事。
    macros.set("POneAssocCyclesDriven", fmt(data.mean_cycles("constraint", data.assoc), 2))
    macros.set("POneAssocCyclesBudget", fmt(data.mean_cycles("budget", data.assoc), 2))
    na_driven = data.mean_cycles("constraint", data.nonassoc)
    na_budget = data.mean_cycles("budget", data.nonassoc)
    macros.set("POneNaCyclesDriven", fmt(na_driven, 2))
    macros.set("POneNaCyclesBudget", fmt(na_budget, 2))
    macros.set("POneNaPriceRatio", fmt(na_driven / na_budget, 2))
    macros.set("POneNaLanesBudget", fmt(data.mean_lanes("budget", data.nonassoc), 2))

    # --- 风险识别 -------------------------------------------------------
    macros.set("POneCoreSize", p["core_dataset_size"])
    macros.set("POneCoreExact", int(p["core_exact_match"] * p["core_dataset_size"]))
    macros.set("POneRobust", p["robustness"]["total"])
    macros.set("POneRobustPass", p["robustness"]["passed"])
    macros.set("POneLimitations", len(p["known_limitations"]))
    macros.set("POneRiskSnippets", s["risk_snippets"])
    macros.set("POneRiskExact", s["risk_exact"])
    macros.set("POneRiskRejectN", sum(1 for r in data.risky if r["group"] == "reject"))
    macros.set("POneRiskShouldReject", s["risk_should_reject"])
    macros.set("POneRiskRejected", s["risk_rejected_by_us"])
    macros.set("POneRiskFalseReject", s["risk_false_reject"])
    macros.set("POneLabels", len(p["per_label"]))

    # --- 综合成本 -------------------------------------------------------
    synth = [r for r in data.runs if r.get("status") == "ok"]
    if not synth:
        raise SystemExit("没有任何综合成功的运行：成本数字不能凭空给")
    macros.set("POneSynthRuns", len(synth))
    times = [r["time_per_vector_ns"] for r in synth if r.get("time_per_vector_ns")]
    macros.set("POneNsMin", fmt(min(times), 1))
    macros.set("POneNsMax", fmt(max(times), 1))
    fmaxes = [r["fmax_mhz"] for r in synth if r.get("fmax_mhz")]
    macros.set("POneFmaxMin", fmt(min(fmaxes), 1))
    macros.set("POneFmaxMax", fmt(max(fmaxes), 1))

    # --- 初始化控制（Discussion 段引用） --------------------------------
    # 正文声称：错误初值在 min 上造成大比例失败，在 max 上不敏感。
    # 该段落的所有数字必须来自 init_controlled.json，不允许手抄。
    init_rows = {r["operator"]: r for r in data.init_control["rows"]}
    for op in ("max", "min"):
        if op not in init_rows:
            raise SystemExit(f"init_controlled.json 缺少算子 {op}，正文初始化段落无法支撑")
    if init_rows["max"]["failures"] != 0:
        raise SystemExit("初始化控制断言不成立：max 的错误初值不应造成失败（0 是其合法单位元）")
    if init_rows["min"]["failures"] < 1:
        raise SystemExit("初始化控制断言不成立：min 的错误初值应造成失败")
    if init_rows["max"]["vectors"] != init_rows["min"]["vectors"]:
        raise SystemExit("初始化控制两个算子的向量数不一致")
    macros.set("POneInitVectors", init_rows["min"]["vectors"])
    macros.set("POneInitMinFail", init_rows["min"]["failures"])
    macros.set("POneInitMaxFail", init_rows["max"]["failures"])
    nz = {r["variant"]: r for r in data.nonzero_init["results"]}
    good, bad = nz["correct_identity_once"], nz["broken_restart_s_per_lane"]
    if good["failures"] != 0 or bad["failures"] < 1:
        raise SystemExit("nonzero-init RTL 对照未形成正确/错误分离")
    macros.set("POneNzVectors", good["vectors"])
    macros.set("POneNzGoodFail", good["failures"])
    macros.set("POneNzBadFail", bad["failures"])
    macros.set("POnePbFiles", data.polybench_admission["files"])
    macros.set("POnePbAccepted", data.polybench_admission["accepted"])
    macros.set("POnePbFixedNReject", data.polybench_admission["rejection_reasons"].get("no_fixed_N_contract", 0))

    # --- PolyBench 最内层循环端到端样本（Results polybench 小节引用） ----
    # 命中/冒险/端到端全部由 run_polybench_concrete.py 机械判定；这里只做
    # 断言与投影，数字不允许手抄。
    pbc = data.polybench_concrete
    if pbc.get("complete") is not True:
        raise SystemExit("polybench_concrete.json 的 complete 不为 true：实验被中断，数字不可用。")
    pbc_runs = pbc["runs"]
    pbc_ppa = [r for r in pbc_runs if r.get("fmax_mhz")]
    mul_row = sum(1 for e in pbc["end_to_end"] if e["elem"] == "mul" and "row" in e["class"])
    id_col = sum(1 for e in pbc["end_to_end"] if e["elem"] == "id")
    if sum(1 for r in pbc_runs if r["functional_pass"]) != len(pbc_runs):
        raise SystemExit("PolyBench 具体化样本存在功能失败的策略运行，正文断言不成立")
    macros.set("POnePbCScanned", pbc["summary"]["scanned"])
    macros.set("POnePbCMatched", pbc["summary"]["matched_files"])
    macros.set("POnePbCMulRow", mul_row)
    macros.set("POnePbCIdCol", id_col)
    macros.set("POnePbCHazards", len(pbc["hazard_excluded"]))
    macros.set("POnePbCKernels", pbc["summary"]["kernels_end_to_end"])
    macros.set("POnePbCVectors", pbc["summary"]["vector_checks"])
    macros.set("POnePbCRuns", pbc["summary"]["runs_total"])
    macros.set("POnePbCDsp", pbc["summary"]["dsp_kernels"])
    macros.set("POnePbCFmaxSlow", fmt(min(r["fmax_mhz"] for r in pbc_ppa), 1))
    macros.set("POnePbCFmaxFast", fmt(max(r["fmax_mhz"] for r in pbc_ppa), 1))

    # --- 穷举 N=3 扩展（Results 非结合小节引用） ------------------------
    # 正文声称：sub_l / sub_r 各 4096 个四比特三元组上，一通道 RTL 与独立
    # 参考完全一致，而非法三通道合并大量失败。数字必须来自
    # exhaustive_n3/summary.json，不允许手抄。
    n3 = {}
    for row in data.exhaustive_n3["results"]:
        n3[(row["operator"], row["policy"])] = row
    n3_vectors = {row["vectors"] for row in data.exhaustive_n3["results"]}
    if len(n3_vectors) != 1:
        raise SystemExit("exhaustive_n3 各行向量数不一致")
    n3_vec = n3_vectors.pop()
    if n3_vec != 16 ** 3:
        raise SystemExit(f"exhaustive_n3 向量数 {n3_vec} != 16^3，与正文'四比特三元组'陈述不符")
    for op in ("sub_l", "sub_r"):
        for policy in ("rolled", "parse_driven"):
            if (op, policy) not in n3:
                raise SystemExit(f"exhaustive_n3 缺少 {op}/{policy} 行")
            if n3[(op, policy)]["failures"] != 0:
                raise SystemExit(f"exhaustive_n3 断言不成立：{op}/{policy} 应全部一致")
        if (op, "illegal_parallel") not in n3:
            raise SystemExit(f"exhaustive_n3 缺少 {op}/illegal_parallel 行")
        ill = n3[(op, "illegal_parallel")]
        if ill["failures"] < 1:
            raise SystemExit(f"exhaustive_n3 断言不成立：{op} 非法并行应有失败")
        if ill["lanes"] != 3:
            raise SystemExit(f"exhaustive_n3 断言不成立：{op} 非法并行通道数应为 3")
    n3_ops = {row["operator"] for row in data.exhaustive_n3["results"]}
    macros.set("POneNThreeVectors", n3_vec)
    macros.set("POneNThreeTotal", n3_vec * len(n3_ops))
    macros.set("POneNThreeLanes", n3[("sub_l", "illegal_parallel")]["lanes"])
    macros.set("POneNThreeSubLFail", n3[("sub_l", "illegal_parallel")]["failures"])
    macros.set("POneNThreeSubRFail", n3[("sub_r", "illegal_parallel")]["failures"])

    # --- sub_l 代数重写并行策略（审稿"回退无价值"的正面回应） -----------
    data.rw = load_json(root / "paper1/results/rewrite_strategy/rewrite_strategy.json")
    if data.rw.get("complete") is not True:
        raise SystemExit("rewrite_strategy.json 的 complete 不为 true：实验被中断")
    if data.rw["summary"]["kernels_functional"] != data.rw["summary"]["kernels"]:
        raise SystemExit("重写策略存在功能失败，正文断言不成立")
    macros.set("POneRwKernels", data.rw["summary"]["kernels"])
    macros.set("POneRwPass", data.rw["summary"]["kernels_functional"])
    macros.set("POneRwSubL", data.rw["summary"]["sub_l_kernels"])
    macros.set("POneRwSubLPass", data.rw["summary"]["sub_l_functional"])
    macros.set("POneRwSubLRatio", fmt(data.rw["summary"]["sub_l_parallel_ratio"], 2))

    # --- 随机策略失败的算子类别分解（审稿 Q：52/64 的通过来自哪些类） ---
    rnd = [r for r in data.generation["runs"]
           if r["strategy"] == "random" and not r.get("identical_to_seed0")]
    kmeta = {k["kernel"]: k for k in data.generation["kernels"]}
    fail_nonassoc = sum(1 for r in rnd if not r.get("functional_pass")
                        and kmeta[r["kernel"]]["associative"] is False)
    fail_total = sum(1 for r in rnd if not r.get("functional_pass"))
    if fail_nonassoc != fail_total:
        raise SystemExit("随机策略失败存在非结合归约之外的类别，正文断言不成立")
    macros.set("POneRandomFailNonAssoc", fail_nonassoc)

    tables = {
        "tables/parse.tex": table_parse(data),
        "tables/strategy.tex": table_strategy(data),
        "tables/nonassoc.tex": table_nonassoc(data),
        "tables/ppa.tex": table_ppa(data),
        "tables/pbconcrete.tex": table_pb_concrete(data),
    }
    figs = {
        "figs/rates.tex": fig_rates(data),
        "figs/latency.tex": fig_latency(data),
    }

    submission.mkdir(parents=True, exist_ok=True)
    (submission / "tables").mkdir(exist_ok=True)
    (submission / "figs").mkdir(exist_ok=True)
    (submission / "numbers.tex").write_text(macros.render(), encoding="utf-8")
    for name, content in {**tables, **figs}.items():
        (submission / name).write_text(content, encoding="utf-8")
    print(f"已生成 numbers.tex（{len(macros.values)} 个宏）、{len(tables)} 张表、{len(figs)} 张图 -> {submission}")


def table_pb_concrete(data: Data) -> str:
    """PolyBench 具体化样本的实测成本表：rolled (L=1) 与 full (L=8) 两个极端策略。

    只取 seed-0 的真实综合记录（runs 里只有 functional 的 seed-0 会被送后端）；
    缺任何一行就硬失败，不允许静默缺行。
    """
    lines = [
        "\\begin{table}[tb]",
        "\\centering",
        "\\caption{Concretized PolyBench innermost-loop samples of",
        "\\S\\ref{sec:results-pb}, measured end-to-end on LFE5U-25F under the two",
        "extreme lane policies (seed-0 runs). DSP blocks appear only in the",
        "multiplication class, and the frequency column shows the lane count",
        "buying parallelism at the price of $f_{\\max}$. Samples in the same class",
        "concretize to the same loop form under the declared rules, hence identical",
        "designs and identical numbers.}",
        "\\label{tab:pbconcrete}",
        "\\scriptsize",
        "\\begin{tabular}{llrrrrrr}",
        "\\toprule",
        " & & \\multicolumn{3}{c}{$L{=}1$ (rolled)} & \\multicolumn{3}{c}{$L{=}8$ (full)} \\\\",
        "\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}",
        "Sample & Class & LUT & DSP & $f_{\\max}$ (MHz) & LUT & DSP & $f_{\\max}$ (MHz) \\\\",
        "\\midrule",
    ]
    for entry in data.polybench_concrete["end_to_end"]:
        runs = {r["strategy"]: r for r in entry["runs"] if r.get("fmax_mhz")}
        rolled, full = runs.get("rolled"), runs.get("full")
        if rolled is None or full is None:
            raise SystemExit(f"polybench_concrete: {entry['kernel']} 缺 L=1 或 L=8 的综合记录")
        elem, axis = entry["elem"], entry["class"].split("/")[2]
        name = entry["kernel"].replace("pb_", "")
        lines.append(
            f"\\texttt{{{name}}} & {elem}/{axis} & "
            f"{rolled['lut']} & {rolled['dsp']} & {fmt(rolled['fmax_mhz'], 1)} & "
            f"{full['lut']} & {full['dsp']} & {fmt(full['fmax_mhz'], 1)} \\\\"
        )
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{table}", ""]
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="生成 paper1 投稿资产")
    parser.add_argument("--submission", default="paper1/submission")
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    submission = (
        (root / args.submission).resolve() if not Path(args.submission).is_absolute() else Path(args.submission)
    )
    build(root, submission)


if __name__ == "__main__":
    main()
