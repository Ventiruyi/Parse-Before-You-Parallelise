"""非零初值 min 归约的 RTL 闭环对照实验。

比较正确的 "identity per lane; s once at final merge" 和错误的
"each lane starts at zero"。对 min 而言，重启同一个 s 是幂等的而非错误；
零才是违反 min identity 的受控错误。测试台由 Icarus 实际仿真；参考值由独立
Python 模型计算。
"""
from __future__ import annotations
import json, random, shutil, subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'/'nonzero_init_rtl'

def reference(s, xs):
    return min([s,*xs])

def rtl(name, broken):
    # 两条 lane 各处理交错的两个元素。正确实现以 all-ones 作为每 lane identity，
    # 在最后才将源程序的非零 s 合并一次。
    starts = "32'd0" if broken else "32'hffffffff"
    final = "min2(min2(32'd37,p0),p1)"
    return f'''module {name}(input wire clk,input wire start,input wire [31:0] a0,a1,a2,a3,output reg [31:0] y,output reg valid);
function [31:0] min2; input [31:0] x,z; begin min2=(x<z)?x:z; end endfunction
reg [31:0] p0,p1; always @(posedge clk) begin
 if(start) begin p0<={starts}; p1<={starts}; valid<=0; end
 else if(!valid) begin p0<=min2(min2(p0,a0),a2); p1<=min2(min2(p1,a1),a3); valid<=1; end
 else begin y<={final}; valid<=0; end end
endmodule
'''

def main():
    suite = ROOT.parent / 'tools' / 'oss-cad-suite' / 'bin'
    if not shutil.which('iverilog') and not (suite/'iverilog.exe').exists():
        raise SystemExit('iverilog unavailable')
    OUT.mkdir(parents=True,exist_ok=True)
    rng=random.Random(20270922); rows=[]
    # 48 含小于 s 的正常向量，16 个全部大于 s 的定向反例；后者只会暴露错误实现。
    for i in range(64):
        xs=[rng.randrange(0,80) if i<48 else rng.randrange(38,256) for _ in range(4)]
        rows.append(xs)
    for variant in ('correct_identity_once','broken_restart_s_per_lane'):
        mod='dut'; (OUT/f'{variant}.v').write_text(rtl(mod,variant.startswith('broken')),encoding='utf-8')
        tb=['module tb; reg clk=0,start=1; reg [31:0] a0,a1,a2,a3; wire [31:0] y; wire valid;',
            'dut d(clk,start,a0,a1,a2,a3,y,valid); always #5 clk=~clk; initial begin']
        for index,xs in enumerate(rows):
            tb += [f"a0=32'd{xs[0]};a1=32'd{xs[1]};a2=32'd{xs[2]};a3=32'd{xs[3]};start=1; @(posedge clk); #1; start=0; @(posedge clk); #1; @(posedge clk); #1; $display(\"R {index} %0d\",y);"]
        tb += ['$finish; end endmodule']
        (OUT/'tb.v').write_text('\n'.join(tb),encoding='utf-8')
        exe=OUT/f'{variant}.out'; iv=str(suite/'iverilog.exe'); vvp=str(suite/'vvp.exe')
        cp=subprocess.run([iv,'-g2012','-o',str(exe),str(OUT/f'{variant}.v'),str(OUT/'tb.v')],capture_output=True,text=True)
        if cp.returncode: raise RuntimeError(cp.stderr)
        sim=subprocess.run([vvp,str(exe)],capture_output=True,text=True,check=True)
        got=[int(line.split()[2]) for line in sim.stdout.splitlines() if line.startswith('R ')]
        expected=[reference(37,x) for x in rows]
        failures=sum(a!=b for a,b in zip(got,expected))
        (OUT/f'{variant}.log').write_text(sim.stdout,encoding='utf-8')
        result={'variant':variant,'vectors':64,'source_init':37,'lane_identity':'0xffffffff' if variant.startswith('correct') else '0','failures':failures,'agreement':round((64-failures)/64,4)}
        (OUT/f'{variant}.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(json.dumps(result))
    summary={'experiment':'nonzero_init_min_rtl','semantics':'min fold initialized with s=37; two interleaved lanes; source init injected once after identity-started partial folds','vectors':64,'reference':'independent Python min([s, elements])','results':[json.loads((OUT/f'{x}.json').read_text()) for x in ('correct_identity_once','broken_restart_s_per_lane')]}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
if __name__=='__main__': main()
