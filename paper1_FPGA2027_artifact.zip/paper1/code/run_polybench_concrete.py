r"""PolyBench 最内层循环的端到端具体化实验（论文一审稿 MAJOR-4 的方案①）。

为什么只具体化"最内层归约语句"
------------------------------
生成器的车道切分要求元素函数是**车道局部**的（每个通道只读自己的元素，
见 hls_flow.ELEM_RTL），这是 RTL 结构的硬前提；PolyBench 的 kernel 主体是
二维数组 + 嵌套循环 + 浮点，没有谁能整体通过语义契约。可证伪的正面主张
因此收窄为：**真实基准文件里被最内层循环携带的归约语句，是否落入生成器
已登记的语句类**。这一步完全机械：在 ``#pragma scop`` 区间做括号配对扫描，
对每条语句按模板分类；命中的原始语句文本逐字记入结果 JSON 并可回链到
源文件。未命中的文件（二维累加、标量累加、读后写冒险）如实计入未匹配。

三条声明的具体化规则（全部写死在本文件，无手工步骤）
----------------------------------------------------
1. **数据集钉死**：N = 8，与微内核数据集同一理由——器件 IO 预算
   （2·N·W ≤ CABGA256 的 197 个可用 IO，见 hls_dataset._build_kernels）。
2. **定点量化**：浮点公式值 v → ``uint8 round(v·32)``（比例 32 声明于
   QUANT；各 init 公式的值域 ≤ 2，量化后 ≤ 254，无截断）。
3. **轴物化**：二维数组沿钉死下标 PIN=1 的那一行/列物化成一维 ``a``，
   向量操作数物化成 ``b``；0 号激励向量用各 kernel 的 ``init_array``
   公式在 n=8 处的量化值，其余向量沿用主实验的确定性伪随机方案。

什么这不是
----------
这不是"PolyBench 端到端 kernel"：二维/嵌套/浮点/循环携带整体仍然在契约
之外，正文里如实写为 future work。这里测的是**前端对真实基准循环形态的
覆盖与全链路可跑通性**（gcc 参考 → 五策略生成 → 仿真 → ECP5 实测），
不是对完整 kernel 的覆盖。

为什么要有"冒险排除"判据
------------------------
``x[i] = x[i] - L[i][k]*x[k]``（trisolv/cholesky）在语句形态上是合法的
减法归约，但累加器 x 同时是元素操作数：x[k] 是前几轮外层迭代的**输出**，
把它物化成常数行就改变了语义。机械判据"累加器变量不得出现在元素操作数
里"把这类语句排除在端到端样本之外，排除本身也记录进结果 JSON。
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

from hls_dataset import Kernel, make_vectors, vectors_to_text
from hls_flow import parse_kernel
from run_hls_experiment import (
    SEEDS, STRATEGIES, backend_metrics, find_tool, run_backend,
    simulate, strategy_lanes,
)

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "paper2" / "data" / "PolyBenchC-4.2.1"
ADMISSION = ROOT / "paper1" / "results" / "polybench_admission.json"
OUTPUT = ROOT / "paper1" / "results" / "polybench_concrete"

N_ELEMENTS = 8      # 规则 1：与微内核 n8 同一器件 IO 预算
QUANT = 32          # 规则 2：定点量化比例
PIN = 1             # 规则 3：二维数组被物化的下标
VECTOR_ROWS = 12    # 与主实验一致：0 号 = init 公式数据，其余为确定性伪随机
LANE_BUDGET = 4

# ---------------------------------------------------------------------------
# 语句模板：acc[P] 由最内层循环 R 携带，二维数组沿 {P,R} 两轴取值
# ---------------------------------------------------------------------------

_ARR2 = r'(?P<arr>\w+)\[(?P<a1>[a-z])\]\[(?P<a2>[a-z])\]'
_VEC1 = r'(?P<vec>\w+)\[(?P<v1>[a-z])\]'
_ACC = r'(?P<acc>\w+)\[(?P<p>[a-z])\]'
_ACC2 = r'(?P<acc2>\w+)\[(?P<p2>[a-z])\]'

# mul 归约的五种书写顺序；op 为 '-' 时映射到 sub_l（非结合，策略层强制 L=1）
MUL_FORMS = [
    ("acc_first", re.compile(rf"^{_ACC}\s*=\s*{_ACC2}\s*(?P<op>[+\-])\s*{_ARR2}\s*\*\s*{_VEC1}\s*;$")),
    ("elem_first", re.compile(rf"^{_ACC}\s*=\s*{_ARR2}\s*\*\s*{_VEC1}\s*(?P<op>[+\-])\s*{_ACC2}\s*;$")),
    ("plus_equals", re.compile(rf"^{_ACC}\s*\+=\s*{_ARR2}\s*\*\s*{_VEC1}\s*;$")),
    ("minus_equals", re.compile(rf"^{_ACC}\s*-=\s*{_ARR2}\s*\*\s*{_VEC1}\s*;$", re.I)),
]
ID_FORMS = [
    ("acc_first", re.compile(rf"^{_ACC}\s*=\s*{_ACC2}\s*(?P<op>[+\-])\s*{_ARR2}\s*;$")),
    ("plus_equals", re.compile(rf"^{_ACC}\s*\+=\s*{_ARR2}\s*;$")),
    ("minus_equals", re.compile(rf"^{_ACC}\s*-=\s*{_ARR2}\s*;$")),
]


def scop_statements(stripped: str) -> list[tuple[str, list[str]]]:
    """抽出 ``#pragma scop`` 区间内的语句与其循环嵌套栈。

    先用 ``re.split`` 把 for 头与花括号**整体**切出来，再把剩余文本按 ``;``
    切成语句——不能让语句分支从空白处起配（``finditer`` 的最左匹配会连 for
    头一起吞掉，这是本扫描器踩过的坑）。PolyBench 的循环体有带花括号和不带
    花括号两种写法（atax 里两种都有）：悬空循环头的体是紧随其后的一条语句或
    嵌套 for，因此对悬空变量在语句之后即闭合。
    """
    match = re.search(r"#pragma\s+scop(.*?)#pragma\s+endscop", stripped, re.S)
    if not match:
        return []
    open_vars: list[str] = []     # 已用花括号开体的循环，由 } 闭合
    pending_vars: list[str] = []  # 悬空循环头，语句后即闭合
    out: list[tuple[str, list[str]]] = []
    for part in re.split(r"(for\s*\([^)]*\)|\{|\})", match.group(1)):
        if not part:
            continue
        if part.startswith("for"):
            var = re.match(r"for\s*\(\s*(\w+)", part)
            if var:
                pending_vars.append(var.group(1))
        elif part == "{":
            open_vars.extend(pending_vars)
            pending_vars.clear()
        elif part == "}":
            if open_vars:
                open_vars.pop()
        else:
            statements = [" ".join(s.split()) for s in part.split(";")]
            statements = [s for s in statements if s]
            if not statements:
                continue  # 纯空白块（for 头与 { 之间）：不得清空悬空循环头
            for index, stmt in enumerate(statements):
                # 悬空循环的体只有第一条语句；同块内的后续语句已在循环之外。
                stack = open_vars + (pending_vars if index == 0 else [])
                out.append((stmt + ";", stack))
            pending_vars.clear()
    return out


def classify(stmt: str, stack: list[str]) -> dict[str, Any] | None:
    """按登记模板给语句分类。

    返回 ``{"status": "match", ...}``（可具体化）或 ``{"status": "hazard",
    ...}``（形态命中但累加器同时是元素操作数，如 trisolv/cholesky 的
    ``x[i] = x[i] - L[i][k]*x[k]``：x[k] 是前几轮外层迭代的输出，物化成
    常数行会改变语义）。返回 None 表示不属于任何登记形态。

    语义锚点：**累加器下标 P 是被物化的外层变量，最内层循环变量 R 才是
    归约变量**。vec 操作数的下标必须是 R（随循环变化的真向量）；二维数组
    的两个下标必须恰为 {P, R}（行式或列式）。vec 下标若等于 P，它是钉死
    标量（如 bicg 的 ``r[i]*A[i][j]``），不落入任何登记类。
    """
    if len(stack) < 2:
        return None
    reduced, pinned = stack[-1], stack[:-1]
    for kind, forms, elem in (("mul", MUL_FORMS, "mul"), ("id", ID_FORMS, "id")):
        for form_name, pattern in forms:
            m = pattern.match(stmt)
            if not m:
                continue
            gd = m.groupdict()
            base = {
                "statement": stmt, "form": form_name, "elem": elem,
                "pinned_var": gd["p"], "reduce_var": reduced,
                "array": gd["arr"], "vector": gd.get("vec"),
            }
            if gd.get("p2", gd["p"]) != gd["p"] or (
                kind == "mul" and "acc2" in gd and gd["acc"] != gd["acc2"]
            ):
                continue
            if gd["p"] not in pinned:
                continue
            if gd["a1"] == gd["a2"] or {gd["a1"], gd["a2"]} != {gd["p"], reduced}:
                continue
            if kind == "mul" and gd["v1"] != reduced:
                continue
            op = gd.get("op") or "+"
            if gd["acc"] in (gd["arr"], gd.get("vec")):
                # 形态命中但累加器是元素操作数：记录为冒险，而不是静默跳过。
                return {"status": "hazard", "op": op, **base}
            return {
                "status": "match",
                "reduce": "+" if op == "+" else "sub_l",
                "axis": "row" if m["a1"] == m["p"] else "col",
                **base,
            }
    return None


# ---------------------------------------------------------------------------
# 规则 3 的数据来源：各文件 init_array 公式的逐字转录（n=m=8）
# 二维公式以 f(i, j) 二元形式给出，行式物化取 f(PIN, k)，列式取 f(k, PIN)。
# ---------------------------------------------------------------------------

FORMULAS: dict[str, dict[str, Any]] = {
    "linear-algebra/kernels/atax/atax.c": {
        "A": lambda i, j: ((i + j) % 8) / 40.0,   # ((i+j)%n)/(5*m)
        "x": lambda k: 1 + k / 8.0,               # 1 + (i/n)
    },
    "linear-algebra/blas/gesummv/gesummv.c": {
        "A": lambda i, j: ((i * j + 1) % 8) / 8.0,  # ((i*j+1)%n)/n
        "B": lambda i, j: ((i * j + 2) % 8) / 8.0,  # ((i*j+2)%n)/n
        "x": lambda k: (k % 8) / 8.0,               # (i%n)/n
    },
    "linear-algebra/kernels/mvt/mvt.c": {
        "A": lambda i, j: (i * j % 8) / 8.0,        # (i*j%n)/n
        "y_1": lambda k: ((k + 3) % 8) / 8.0,       # ((i+3)%n)/n
        "y_2": lambda k: ((k + 4) % 8) / 8.0,
    },
    "linear-algebra/kernels/bicg/bicg.c": {
        "A": lambda i, j: (i * (j + 1) % 8) / 8.0,  # (i*(j+1)%n)/n
        "p": lambda k: (k % 8) / 8.0,               # (i%m)/m
        "r": lambda k: (k % 8) / 8.0,               # (i%n)/n
    },
    "datamining/covariance/covariance.c": {
        "data": lambda i, j: (i * j) / 8.0,          # ((DATA_TYPE)i*j)/M
    },
    "datamining/correlation/correlation.c": {
        "data": lambda i, j: (i * j) / 8.0 + i,      # (i*j)/M + i
    },
}


def quantized(values: list[float]) -> list[int]:
    """规则 2：uint8 定点量化。公式值域 ≤ 2 时不会触到截断边界。"""
    out = []
    for value in values:
        q = round(value * QUANT)
        if not 0 <= q <= 255:
            raise ValueError(f"量化值越界：{value} -> {q}（公式值域超出声明假设）")
        out.append(q)
    return out


def derive_arrays(file_rel: str, hit: dict[str, Any]) -> tuple[list[int], list[int]]:
    """按命中语句的数组名与轴向，从 init 公式物化出 (a, b) 两条一维数组。"""
    table = FORMULAS.get(file_rel)
    if table is None:
        raise ValueError(f"{file_rel}: 命中语句没有对应的具体化公式")
    size = N_ELEMENTS
    indices = list(range(size))
    if hit["elem"] == "mul":
        arr_fn = table.get(hit["array"])
        vec_fn = table.get(hit["vector"])
        if arr_fn is None or vec_fn is None:
            raise ValueError(f"{file_rel}: 公式表缺 {hit['array']} 或 {hit['vector']}")
        if hit["axis"] == "row":
            a = quantized([arr_fn(PIN, k) for k in indices])
        else:
            a = quantized([arr_fn(k, PIN) for k in indices])
        b = quantized([vec_fn(k) for k in indices])
    else:
        arr_fn = table.get(hit["array"])
        if arr_fn is None:
            raise ValueError(f"{file_rel}: 公式表缺 {hit['array']}")
        if hit["axis"] == "row":
            a = quantized([arr_fn(PIN, k) for k in indices])
        else:
            a = quantized([arr_fn(k, PIN) for k in indices])
        b = [0] * size  # id 元素不读 b，占位为零
    return a, b


def concretized_source(kernel: Kernel, file_rel: str, hit: dict[str, Any]) -> str:
    """发射生成器的规范 kernel 形态，并在头部记录来源与原语句。

    唯一的文本差异是注释：parse_kernel 会剥掉注释，因此"具体化文件能被
    前端接受"不是因为放宽了解析器，而是因为形态本来就在契约之内。
    """
    body = kernel.c_source().splitlines()
    provenance = [
        f"/* Concretized innermost-loop sample derived from",
        f" * PolyBench/C 4.2.1 {file_rel}",
        f" * original statement : {hit['statement']}",
        f" * class              : {hit['elem']}-reduce ({hit['reduce']}), {hit['axis']} axis,",
        f" *                      pinned var {hit['pinned_var']}={PIN}, reduce var {hit['reduce_var']}",
        f" * rules              : N={N_ELEMENTS} (device IO budget), uint8 fixed-point v*{QUANT}",
        f" *                      stimulus row 0 from this kernel's init_array formulas */",
    ]
    insert_at = next(i for i, line in enumerate(body) if line.startswith("typedef"))
    return "\n".join(body[:insert_at] + provenance + body[insert_at:]) + "\n"


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


def run_gcc(gcc: str, case: Path, source_text: str, vectors) -> list[int]:
    case.mkdir(parents=True, exist_ok=True)
    source = case / "kernel.c"
    source.write_text(source_text, encoding="utf-8")
    exe = case / ("kernel.exe" if os.name == "nt" else "kernel")
    compiled = subprocess.run([gcc, "-O1", "-std=c99", "-o", str(exe), str(source)],
                              text=True, capture_output=True, check=False)
    if compiled.returncode != 0:
        raise RuntimeError(f"gcc 编译失败：{(compiled.stderr or '')[:400]}")
    vector_file = case / "vectors.txt"
    vector_file.write_text(vectors_to_text(vectors), encoding="utf-8")
    run = subprocess.run([str(exe), str(vector_file)], text=True, capture_output=True, check=False)
    if run.returncode != 0:
        raise RuntimeError(f"参考程序运行失败：{(run.stderr or '')[:400]}")
    return [int(line.split()[0]) for line in (run.stdout or "").strip().splitlines()]


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    incomplete = {
        "experiment": "paper1_polybench_innermost_loop_concretization",
        "complete": False,
        "note": "本轮实验尚未跑完；complete=false 的清单不可引用。",
    }
    (OUTPUT / "polybench_concrete.json").write_text(
        json.dumps(incomplete, ensure_ascii=False, indent=2), encoding="utf-8")

    admission = json.loads(ADMISSION.read_text(encoding="utf-8"))
    files = [row["file"] for row in admission["rows"]]
    gcc = shutil.which("gcc") or "gcc"
    iverilog = find_tool("iverilog", ROOT)
    vvp = find_tool("vvp", ROOT)

    # --- 第一步：机械扫描 30 个文件的最内层归约语句 ---------------------
    scanned: list[dict[str, Any]] = []
    for file_rel in files:
        raw = (SRC / file_rel).read_text(encoding="utf-8", errors="replace")
        from c_parser import strip_comments_and_strings
        stripped = strip_comments_and_strings(raw)
        hits, hazards = [], []
        for stmt, stack in scop_statements(stripped):
            verdict = classify(stmt, stack)
            if verdict is None:
                continue
            if verdict["status"] == "match":
                hits.append(verdict)
            else:
                hazards.append(verdict)
        scanned.append({"file": file_rel, "hits": hits, "hazards": hazards})

    matched = [entry for entry in scanned if entry["hits"]]
    excluded_hazard = [
        {"file": entry["file"], "statement": h["statement"]}
        for entry in scanned for h in entry["hazards"]
    ]

    # --- 第二步：对命中且无冒险的文件跑端到端管线 -----------------------
    e2e: list[dict[str, Any]] = []
    runs: list[dict[str, Any]] = []
    for entry in matched:
        file_rel, hit = entry["file"], entry["hits"][0]
        short = Path(file_rel).stem
        kernel = Kernel(name=f"pb_{short}", count=N_ELEMENTS, width=8,
                        elem=hit["elem"], reduce=hit["reduce"], mode="reduce")
        source_text = concretized_source(kernel, file_rel, hit)
        constraint = parse_kernel(source_text)  # 前端准入；失败即抛出，不静默

        vectors = make_vectors(kernel, VECTOR_ROWS, seed=12345)
        a0, b0 = derive_arrays(file_rel, hit)
        vectors[0] = (a0, b0)  # 0 号 = init 公式数据（规则 3）

        case = OUTPUT / kernel.name / "c"
        reference = run_gcc(gcc, case, source_text, vectors)
        model = [kernel.reference_packed(a, b) for a, b in vectors]
        model_agrees = model == reference

        legal = constraint.legal_lanes(constraint.count)
        record = {
            "file": file_rel,
            "statement": hit["statement"],
            "class": f"{hit['elem']}-reduce/{hit['reduce']}/{hit['axis']}",
            "kernel": kernel.name,
            "elem": hit["elem"],
            "reduce": hit["reduce"],
            "admitted": True,
            "model_agrees_with_gcc": model_agrees,
            "vectors": len(vectors),
            "reference_values": reference,
            "runs": [],
        }
        for strategy in STRATEGIES:
            for seed in range(SEEDS):
                lanes = strategy_lanes(constraint, strategy, seed, LANE_BUDGET)
                tag = f"{strategy}_s{seed}"
                outcome = simulate(iverilog, vvp, OUTPUT, kernel, constraint, lanes, tag, vectors)
                functional = outcome["compilable"] and outcome["values"] == reference
                run_record: dict[str, Any] = {
                    "strategy": strategy, "seed": seed, "lanes": lanes,
                    "cycles": outcome["cycles"],
                    "rtl_sha256": outcome["rtl_sha256"],
                    "compilable": outcome["compilable"],
                    "functional_pass": bool(functional),
                    "legal": lanes in legal,
                }
                if functional and seed == 0:
                    flow_dir = OUTPUT / f"flow_{kernel.name}__{strategy}"
                    flow_dir.mkdir(parents=True, exist_ok=True)
                    rtl_file = OUTPUT / f"{kernel.name}__{strategy}.v"
                    rtl_file.write_text(outcome["rtl"], encoding="utf-8")
                    code, manifest = run_backend(ROOT, rtl_file, "kernel", flow_dir)
                    run_record["flow_returncode"] = code
                    if manifest is not None:
                        metrics = backend_metrics(manifest)
                        run_record.update(metrics)
                    else:
                        run_record["status"] = "failed"
                record["runs"].append(run_record)
                runs.append({"kernel": kernel.name, **run_record})
        e2e.append(record)

    functional_runs = [r for r in runs if r["functional_pass"]]
    ppa_runs = [r for r in runs if r.get("fmax_mhz")]
    result = {
        "experiment": "paper1_polybench_innermost_loop_concretization",
        "complete": True,
        "design": {
            "n_elements": N_ELEMENTS, "quantization": QUANT, "pinned_index": PIN,
            "vector_rows": VECTOR_ROWS, "lane_budget": LANE_BUDGET, "seeds": SEEDS,
            "strategies": list(STRATEGIES),
        },
        "scanned_files": len(files),
        "matched": scanned,
        "hazard_excluded": excluded_hazard,
        "end_to_end": e2e,
        "runs": runs,
        "summary": {
            "scanned": len(files),
            "matched_files": len(matched),
            "kernels_end_to_end": len(e2e),
            "model_gcc_agreement": sum(1 for r in e2e if r["model_agrees_with_gcc"]),
            "vector_checks": sum(r["vectors"] for r in e2e),
            "runs_total": len(runs),
            "runs_functional": len(functional_runs),
            "runs_synthesized": len(ppa_runs),
            "dsp_kernels": len({r["kernel"] for r in ppa_runs if r.get("dsp")}),
            "fmax_min": min((r["fmax_mhz"] for r in ppa_runs if r.get("fmax_mhz")), default=None),
            "fmax_max": max((r["fmax_mhz"] for r in ppa_runs if r.get("fmax_mhz")), default=None),
        },
        "note": (
            "命中的原始语句文本逐字保留并可回链源文件；具体化只有三条声明规则"
            "（N=8 数据集钉死、uint8 v*32 定点量化、PIN=1 轴物化），无手工步骤；"
            "参考值来自 gcc 对具体化源文件的真实执行。"
        ),
    }
    (OUTPUT / "polybench_concrete.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))
    for entry in matched:
        print(entry["file"], "->", entry["hits"][0]["statement"])


if __name__ == "__main__":
    main()
