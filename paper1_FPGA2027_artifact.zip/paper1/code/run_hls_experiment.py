r"""论文一主实验：解析约束驱动的 C→RTL 生成，端到端真实工具链验证。

证据链（三级，互相独立）
------------------------
1. **参考值来自 gcc。** 每个 kernel 的 C 源码用 gcc 真编译，用同一份激励文件真
   运行，输出即参考值。参考值不是手写常量，也不是从 RTL 反推的。
2. **第三重交叉检查。** 另有 ``hls_dataset.Kernel.python_reference`` 这个按规格
   重写的 Python 模型；它与 gcc 输出必须逐向量一致，否则该 kernel 的参考值
   不可信。两条独立实现同时出错的可能性远低于单点错误。
3. **RTL 与参考值比对。** 生成的 RTL 用 Icarus Verilog 仿真，测试台只打印
   RTL 实际算出的结果（**不含期望值**），比对由本脚本完成。测试台里若写了
   期望值，"参考值来自 C 程序执行"这句话就变成了自证。

五个生成策略
------------
- ``rolled``    : 通道数恒为 1（不掌握解析结果时的保守选择）。
- ``full``      : 通道数恒为 $N$（"全都展开"的固定启发式，有意无视预算）。
- ``budget``    : 不超预算的最大因子（纯资源启发式，**不看算子**）。
- ``random``    : 在预算内的因子里随机（5 个种子）。
- ``constraint``: **按解析约束**选通道数：非结合归约强制 $L=1$，其余取不超预算的
  最大因子。它还决定初值，并在消耗后端预算之前拒绝不可综合的构造。

``budget`` 与 ``constraint`` 是刻意配成一对的**受控对比**：两者都限制在同一资源
预算内、都用"取不超过预算的最大因子"这一条规则，唯一的差别是 ``constraint``
读了 C 语句里的归约算子、因而知道非结合归约不能跨通道合并。这样"性能差异"与
"功能正确性差异"就能干净地归因到"是否掌握了解析结果"这一件事上。

关键的可测后果：``rolled``/``full``/``budget``/``random`` 都不看 C 语句的算子，
所以对 ``sub_l``/``sub_r`` 这类非结合归约，它们会给出编译通过、综合通过、但
**功能错误**的 RTL。这不是推测，而是由 gcc 参考输出直接判定的胜负点。
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
# Windows 控制台默认用 GBK 解码 stdout；一旦回溯里带中文（本项目的异常信息都是
# 中文），日志就会变成乱码，无法作为审计证据。显式把三个标准流固定为 UTF-8。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

from c_parser import CHLSParser
from hls_dataset import KERNELS, Kernel, make_vectors, risk_snippets, vectors_to_text
from hls_flow import Constraint, generate_rtl, parse_kernel, testbench

SEEDS = 5
LANE_BUDGET = 4          # 受预算约束的策略允许的最大通道数（资源预算）
VECTOR_ROWS = 12

# 五个生成策略。
# - rolled     : 通道数恒为 1（不掌握解析结果时的保守选择）。
# - full       : 通道数恒为 N（"全都展开"的固定启发式，有意无视预算）。
# - budget     : 不超预算的最大因子（纯资源启发式，**不看算子**）。
# - random     : 在预算内的因子里随机（5 个种子）。
# - constraint : **按解析约束**选通道数（非结合归约强制 L=1）。
# budget 与 constraint 构成受控对比：同样的预算、同样的"取最大因子"规则，唯一
# 差别是是否读了 C 语句里的算子。
STRATEGIES = ("rolled", "full", "budget", "random", "constraint")


# ---------------------------------------------------------------------------
# 工具定位
# ---------------------------------------------------------------------------


def find_tool(name: str, root: Path) -> str:
    for candidate in (
        root / "tools" / "oss-cad-suite" / "bin" / f"{name}.exe",
        root / "tools" / "oss-cad-suite" / "bin" / name,
    ):
        if candidate.exists():
            os.environ["PATH"] = (
                f"{candidate.parent}{os.pathsep}{candidate.parent.parent / 'lib'}{os.pathsep}"
                + os.environ.get("PATH", "")
            )
            return str(candidate)
    found = shutil.which(name)
    if not found:
        raise SystemExit(f"找不到 {name}")
    return found


_IVERILOG_VERSION = re.compile(r"Icarus Verilog version\s+([0-9][0-9A-Za-z.\-]*)")
_VERSION_NUMBER = re.compile(r"([0-9]+\.[0-9]+(?:\.[0-9]+)?)")


def version_of(tool: str) -> str:
    """取得工具的版本号字符串。

    不能用一个开关一把梭，每个工具认的标志都不同：Icarus Verilog 只认 ``-V``
    （传 ``--version`` 会打印 ``unknown option`` 并把可执行文件的**完整 Windows
    路径**也打出来 —— 那段文本一旦进 LaTeX 宏就是灾难，路径里的反斜杠会被当成
    控制序列起始符）；gcc 不认 ``-V``（它的 ``-V`` 是"用指定版本运行"），只认
    ``-v``。所以这里逐个试探，并把"看起来像报错"的输出整段丢弃，再只抽取版本号
    本身，绝不把工具输出的原始文本带出去。
    """
    for flag in ("-V", "-v", "--version"):
        try:
            completed = subprocess.run([tool, flag], text=True, capture_output=True, check=False)
        except OSError:
            continue
        text = f"{completed.stdout or ''}\n{completed.stderr or ''}"
        lowered = text.lower()
        if "unknown option" in lowered or "unrecognized" in lowered or "error:" in lowered:
            continue
        matched = _IVERILOG_VERSION.search(text)
        if matched:
            return matched.group(1)
        # 先找带 "version" 的行，否则退化为第一处形如 x.y[.z] 的数字。
        for line in text.splitlines():
            if "version" in line.lower():
                number = _VERSION_NUMBER.search(line)
                if number:
                    return number.group(1)
        for line in text.splitlines():
            number = _VERSION_NUMBER.search(line)
            if number:
                return number.group(1)
    return "unknown"


def probe_backend(root: Path) -> tuple[dict[str, Any], str, str]:
    """探测工具链版本与固定配置，返回 (backend 元数据, gcc 路径, iverilog 路径)。

    单独抽出来，是为了让"环境元数据"与"测量结果"可以分开刷新：版本探测的方式
    本身会被修（本项目就修过一次），而重跑整轮实验要二十分钟。两条路径共用本
    函数，因此不会出现两套口径。
    """
    gcc = shutil.which("gcc") or "gcc"
    iverilog = find_tool("iverilog", root)
    backend = {
        "compiler": f"gcc {version_of(gcc)}",
        "simulator": f"Icarus Verilog {version_of(iverilog)}",
        "flow": "yosys-nextpnr-ecp5-ecppack",
        "mapper": "abc -lut 4 (legacy; ABC9 unusable on Windows native Yosys build)",
        "device": "LFE5U-25F CABGA256 speed 6",
    }
    return backend, gcc, iverilog


# ---------------------------------------------------------------------------
# 策略
# ---------------------------------------------------------------------------


def divisors(count: int) -> list[int]:
    return [lanes for lanes in range(1, count + 1) if count % lanes == 0]


def budget_lanes(constraint: Constraint, budget: int) -> int:
    """不看算子的资源策略：在不超过预算的因子里取最大的那个。"""
    allowed = [lanes for lanes in divisors(constraint.count) if lanes <= budget]
    if not allowed:
        raise ValueError(f"预算 {budget} 下没有可用通道数（N={constraint.count}）")
    return max(allowed)


def constraint_lanes(constraint: Constraint, budget: int) -> int:
    """解析约束驱动的通道数选择：非结合归约只能顺序执行（L=1），否则取不超预算的最大因子。

    这里唯一的、也是全部的信息优势，就是"归约算子是否保序"这**一位**：非结合
    （``acc -= e`` / ``acc = e - acc``）时把 N 个元素切成若干通道各累加再合并，
    得到的值与顺序执行不同。除了这一位之外，通道数选择规则与 ``budget_lanes``
    完全一致 —— 两者构成受控对比：同样的资源预算、同样的取最大因子规则，只差
    是否读了 C 语句里的算子。
    """
    if constraint.mode == "reduce" and not constraint.associative:
        return 1
    return budget_lanes(constraint, budget)


def strategy_lanes(constraint: Constraint, strategy: str, seed: int, budget: int) -> int:
    if strategy == "rolled":
        return 1
    if strategy == "full":
        return constraint.count          # 有意无视预算：经典"全都展开"的默认行为
    if strategy == "budget":
        return budget_lanes(constraint, budget)
    if strategy == "random":
        # 随机基线同样限制在预算内：这样它在非结合归约上的失败就只能归因于
        # "没读算子"，而不是"超预算"。若允许它取超预算的通道数，失败就有了第二种
        # 解释，实验就不干净了。
        rng = random.Random(seed * 7919 + constraint.count * 104729)
        allowed = [lanes for lanes in divisors(constraint.count) if lanes <= budget]
        return rng.choice(allowed)
    if strategy == "constraint":
        return constraint_lanes(constraint, budget)
    raise ValueError(f"未知策略：{strategy}")


# ---------------------------------------------------------------------------
# 编译与仿真
# ---------------------------------------------------------------------------


def run_gcc_reference(gcc: str, workdir: Path, kernel: Kernel, vectors: list[tuple[list[int], list[int]]]) -> list[Any]:
    case = workdir / kernel.name / "c"
    case.mkdir(parents=True, exist_ok=True)
    source = case / "kernel.c"
    source.write_text(kernel.c_source(), encoding="utf-8")
    exe = case / ("kernel.exe" if os.name == "nt" else "kernel")
    compiled = subprocess.run(
        [gcc, "-O1", "-std=c99", "-o", str(exe), str(source)],
        text=True, capture_output=True, check=False,
    )
    if compiled.returncode != 0:
        raise RuntimeError(f"{kernel.name}: gcc 编译失败：{(compiled.stderr or '')[:400]}")
    vector_file = case / "vectors.txt"
    vector_file.write_text(vectors_to_text(vectors), encoding="utf-8")
    run = subprocess.run([str(exe), str(vector_file)], text=True, capture_output=True, check=False)
    if run.returncode != 0:
        raise RuntimeError(f"{kernel.name}: 参考程序运行失败：{(run.stderr or '')[:400]}")
    rows: list[Any] = []
    for line in (run.stdout or "").strip().splitlines():
        parts = line.split()
        if kernel.mode == "reduce":
            rows.append(int(parts[0]))
        else:
            packed = 0
            for index, value in enumerate(parts):
                packed |= (int(value) & ((1 << kernel.width) - 1)) << (index * kernel.width)
            rows.append(packed)
    return rows


def simulate(iverilog: str, vvp: str, workdir: Path, kernel: Kernel, constraint: Constraint,
             lanes: int, tag: str, vectors: list[tuple[list[int], list[int]]]) -> dict[str, Any]:
    case = workdir / kernel.name / tag
    case.mkdir(parents=True, exist_ok=True)
    generated = generate_rtl(constraint, kernel.width, lanes)
    rtl_file = case / "kernel.v"
    tb_file = case / "tb.v"
    rtl_file.write_text(generated["rtl"], encoding="utf-8")
    tb_file.write_text(testbench(constraint, kernel.width, vectors), encoding="utf-8")
    vvp_file = case / "sim.vvp"

    def finish(result: dict[str, Any]) -> dict[str, Any]:
        result["cycles"] = generated["cycles"]
        result["rtl_sha256"] = hashlib.sha256(generated["rtl"].encode("utf-8")).hexdigest()[:16]
        result["rtl"] = generated["rtl"]
        result["case_dir"] = str(case)
        return result

    compiled = subprocess.run(
        [iverilog, "-g2012", "-o", str(vvp_file), str(rtl_file), str(tb_file)],
        text=True, capture_output=True, check=False,
    )
    if compiled.returncode != 0:
        return finish({"compilable": False, "values": [], "timeouts": [],
                       "error": (compiled.stderr or "").strip().splitlines()[:4]})
    run = subprocess.run([vvp, str(vvp_file)], text=True, capture_output=True, check=False)
    values: list[int] = []
    timeouts: list[int] = []
    for line in (run.stdout or "").splitlines():
        parts = line.split()
        if len(parts) == 3 and parts[0] == "OUT":
            values.append(int(parts[2], 16))
        elif len(parts) == 2 and parts[0] == "TIMEOUT":
            timeouts.append(int(parts[1]))
    return finish({"compilable": True, "values": values, "timeouts": timeouts, "error": None})


# ---------------------------------------------------------------------------
# 后端
# ---------------------------------------------------------------------------


def run_backend(root: Path, rtl_file: Path, top: str, out_dir: Path) -> tuple[int, dict[str, Any] | None]:
    driver = root / "shared" / "run_ecp5_flow.py"
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest_file = out_dir / "ppa_manifest.json"
    # 这里**不删除**旧清单。每次调用都会重跑流程并覆盖它；万一流程中途失败留下旧
    # 清单，也不会张冠李戴：调用方把 RTL 的 sha256 编进了 out_dir 的名字（见
    # experiment()），所以该目录里出现的清单必然属于同一份 RTL 文本。
    # 用"名字里带内容哈希"来保证归属，比"先删再跑、靠存在性推断新鲜度"更可靠，
    # 也避免了删除操作本身（在本项目的结果目录里，删除会被环境的删除保护拦下）。
    command = [
        sys.executable, str(driver),
        "--rtl", str(rtl_file), "--top", top, "--out", str(out_dir),
        "--device", "25k", "--package", "CABGA256", "--speed", "6", "--freq", "100",
    ]
    completed = subprocess.run(command, cwd=root, text=True, capture_output=True, check=False)
    (out_dir / "driver.stderr.log").write_text(completed.stderr or "", encoding="utf-8")
    if completed.returncode != 0 or not manifest_file.exists():
        return completed.returncode, None
    return 0, json.loads(manifest_file.read_text(encoding="utf-8"))


def backend_metrics(manifest: dict[str, Any]) -> dict[str, Any]:
    report = manifest.get("nextpnr_report", {})
    utilization = report.get("utilization", {})

    def used(name: str) -> int:
        try:
            return int(utilization.get(name, {}).get("used", 0))
        except (AttributeError, TypeError, ValueError):
            return 0

    best: float | None = None
    for domain in report.get("fmax", {}).values():
        try:
            achieved = float(domain.get("achieved", 0.0))
        except (TypeError, ValueError, AttributeError):
            continue
        if achieved > 0 and (best is None or achieved > best):
            best = achieved
    return {
        "lut": used("TRELLIS_COMB"),
        "ff": used("TRELLIS_FF"),
        "dsp": used("MULT18X18D"),
        "bram": used("DP16KD"),
        "fmax_mhz": round(best, 3) if best else None,
        "runtime_s": round(sum(manifest.get("runtimes", {}).values()), 3) or None,
    }


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------


def experiment(root: Path, rows: int, budget: int) -> dict[str, Any]:
    output = root / "paper1" / "results" / "hls_generation"
    output.mkdir(parents=True, exist_ok=True)
    # 不做任何删除。两条原因：
    # 1) 本实验产物文件名是确定的，逐文件覆盖与"先清空再写"等价；
    # 2) 结果目录里已有上千个文件，删除操作会被环境的批量删除保护拦下并要求人工
    #    确认 —— 一个应当能无人值守重跑的脚本不能依赖点确认。
    # 于是改成**先写占位清单并把 complete 置为 false**。被中断的重跑会留下
    # complete=false 的清单，而消费方（emit_report_assets.py）在 complete 不为
    # true 时直接报错退出。这样"半新半旧的数据被当成完整结果"这条最坏路径被堵死，
    # 且全程无需删除。
    incomplete = {
        "experiment": "paper1_parse_constraint_driven_hls_generation",
        "complete": False,
        "measured": False,
        "note": "本轮实验尚未跑完。看到 complete=false 说明上一次运行被中断，"
                "此文件里的任何数字都不可用，请重跑 run_hls_experiment.py。",
    }
    (output / "hls_generation.json").write_text(
        json.dumps(incomplete, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    gcc = shutil.which("gcc") or "gcc"
    iverilog = find_tool("iverilog", root)
    vvp = find_tool("vvp", root)
    parser = CHLSParser()
    backend, _, _ = probe_backend(root)
    kernels: list[dict[str, Any]] = []
    runs: list[dict[str, Any]] = []
    for kernel in KERNELS:
        source = kernel.c_source()
        constraint = parse_kernel(source)
        scan = parser.parse(source)
        vectors = make_vectors(kernel, rows, seed=12345)
        reference = run_gcc_reference(gcc, output, kernel, vectors)
        model = [kernel.reference_packed(a, b) for a, b in vectors]
        model_agrees = model == reference

        legal = constraint.legal_lanes(constraint.count)
        record: dict[str, Any] = {
            "kernel": kernel.name,
            "mode": kernel.mode,
            "count": constraint.count,
            "width": kernel.width,
            "elem": constraint.elem,
            "reduce_op": constraint.reduce_op,
            "associative": constraint.associative,
            "uses_multiplier": constraint.uses_multiplier,
            "synthesizable_scan": scan["synthesizable"],
            "legal_lanes": legal,
            "illegal_lanes": [lanes for lanes in divisors(constraint.count) if lanes not in legal],
            "python_model_agrees_with_gcc": model_agrees,
            "vectors": len(vectors),
            "runs": [],
        }

        # 五个策略一律给 SEEDS 个种子。四个非随机策略的通道数只由 (kernel, 预算)
        # 决定、与种子无关，因此它们的第 2..5 个种子必然产出与 0 号种子**逐字节
        # 相同**的 RTL —— 这正好把"策略是确定性的"这句话变成实测事实，而不是断言。
        # random 是唯一随机的策略，多打几枪才能看出它的失败率。
        for strategy in STRATEGIES:
            first_hash: str | None = None
            for seed in range(SEEDS):
                lanes = strategy_lanes(constraint, strategy, seed, budget)
                tag = f"{strategy}_s{seed}"
                outcome = simulate(iverilog, vvp, output, kernel, constraint, lanes, tag, vectors)
                if seed > 0 and first_hash is not None and outcome["rtl_sha256"] == first_hash:
                    # 同一种子无关的策略在不同种子下产出**同一个 RTL**：不必重复
                    # 仿真，但要把"完全相同"这件事记下来，而不是记成又一次独立通过。
                    record["runs"].append({
                        "strategy": strategy, "seed": seed, "lanes": lanes,
                        "cycles": outcome["cycles"], "rtl_sha256": outcome["rtl_sha256"],
                        "identical_to_seed0": True, "functional_pass": None,
                        "legal": lanes in legal,
                    })
                    continue
                first_hash = first_hash or outcome["rtl_sha256"]
                functional = outcome["compilable"] and outcome["values"] == reference
                run_record: dict[str, Any] = {
                    "strategy": strategy,
                    "seed": seed,
                    "lanes": lanes,
                    "cycles": outcome["cycles"],
                    "rtl_sha256": outcome["rtl_sha256"],
                    "identical_to_seed0": False,
                    "legal": lanes in legal,
                    "compilable": outcome["compilable"],
                    "functional_pass": bool(functional),
                    "timeouts": len(outcome["timeouts"]),
                    "mismatches": (
                        sum(1 for got, want in zip(outcome["values"], reference) if got != want)
                        if outcome["compilable"] else None
                    ),
                    "compile_error": outcome["error"],
                }
                if functional and seed == 0:
                    # 目录名里嵌入该 RTL 的 sha256 前 8 位：这样目录与它所缓存的
                    # 综合产物一一对应，无需任何删除操作来保证新鲜度。
                    case_dir = output / f"flow_{kernel.name}__{strategy}__{outcome['rtl_sha256'][:8]}"
                    case_dir.mkdir(parents=True, exist_ok=True)
                    rtl_file = output / f"{kernel.name}__{strategy}.v"
                    rtl_file.write_text(outcome["rtl"], encoding="utf-8")
                    code, manifest = run_backend(root, rtl_file, "kernel", case_dir)
                    run_record["flow_returncode"] = code
                    if manifest is not None:
                        metrics = backend_metrics(manifest)
                        run_record.update(metrics)
                        run_record["status"] = "ok"
                        run_record["time_per_vector_ns"] = (
                            round(outcome["cycles"] * 1000.0 / metrics["fmax_mhz"], 3)
                            if metrics.get("fmax_mhz") else None
                        )
                    else:
                        run_record["status"] = "failed"
                record["runs"].append(run_record)
                runs.append({"kernel": kernel.name, **run_record})
        kernels.append(record)

    # --- 风险片段的判定质量 ---------------------------------------------
    risky: list[dict[str, Any]] = []
    for name, code, expected, group in risk_snippets():
        scan = parser.parse(code)
        observed = {item["type"] for item in scan["issues"]}
        risky.append({
            "name": name,
            "group": group,
            "expected": sorted(expected),
            "observed": sorted(observed),
            "exact": observed == expected,
            "our_decision": "reject" if observed else "generate",
            "baseline_decision": "generate" if expected else "generate",
            "reason": sorted(observed),
        })

    # --- 汇总 -----------------------------------------------------------
    def strategy_pass_rate(strategy: str) -> dict[str, Any]:
        evaluated = [r for r in runs if r["strategy"] == strategy and not r["identical_to_seed0"]]
        if not evaluated:
            return {"strategy": strategy, "evaluated": 0, "passed": 0, "rate": None}
        passed = sum(1 for r in evaluated if r["functional_pass"])
        return {
            "strategy": strategy,
            "evaluated": len(evaluated),
            "passed": passed,
            "rate": round(passed / len(evaluated), 4),
            "illegal_lane_runs": sum(1 for r in evaluated if not r["legal"]),
            "illegal_but_passed": sum(1 for r in evaluated if not r["legal"] and r["functional_pass"]),
        }

    by_strategy = {s: strategy_pass_rate(s) for s in STRATEGIES}
    synthesized = [r for r in runs if r.get("status") == "ok"]
    legal_runs = [r for r in runs if r["strategy"] == "constraint" or r["legal"]]
    nonassoc_kernels = [k for k in kernels if not k["associative"] and k["mode"] == "reduce"]

    result = {
        "experiment": "paper1_parse_constraint_driven_hls_generation",
        "complete": True,
        "measured": True,
        "backend": backend,
        "design": {
            "kernels": len(kernels),
            "vector_rows": rows,
            "lane_budget": budget,
            "seeds": SEEDS,
            "strategies": list(STRATEGIES),
        },
        "kernels": kernels,
        "runs": runs,
        "risk_snippets": risky,
        "summary": {
            "kernels": len(kernels),
            "reduce_kernels": sum(1 for k in kernels if k["mode"] == "reduce"),
            "map_kernels": sum(1 for k in kernels if k["mode"] == "map"),
            "multiplier_kernels": sum(1 for k in kernels if k["uses_multiplier"]),
            "nonassociative_kernels": len(nonassoc_kernels),
            "model_gcc_agreement": sum(1 for k in kernels if k["python_model_agrees_with_gcc"]),
            "runs_total": len(runs),
            "runs_evaluated": sum(1 for r in runs if not r["identical_to_seed0"]),
            "synthesized": len(synthesized),
            "by_strategy": by_strategy,
            "risk_snippets": len(risky),
            "risk_exact": sum(1 for r in risky if r["exact"]),
            "risk_should_reject": sum(1 for r in risky if r["expected"]),
            "risk_rejected_by_us": sum(1 for r in risky if r["expected"] and r["our_decision"] == "reject"),
            "risk_false_reject": sum(1 for r in risky if not r["expected"] and r["our_decision"] != "generate"),
            "dsp_used_kernels": len({r["kernel"] for r in synthesized if r.get("dsp")}),
            "legal_runs_synthesized": len([r for r in synthesized if r["legal"]]),
        },
        "note": (
            "参考值来自 gcc 真实执行；Python 参考模型与 gcc 输出逐向量交叉检查；"
            "RTL 用 Icarus Verilog 仿真并只打印实测值，比对由驱动脚本完成。"
            "只对每种策略的 0 号种子做真实综合，其余种子仅做仿真；同一策略在不同"
            "种子下若产出同一 RTL，记录为 identical_to_seed0 而不重复计入通过数。"
        ),
    }
    # 顺序很重要：先把 CSV 全部写完，最后才写带 complete=true 的 JSON。JSON 是
    # 本轮产物的"提交标志"，把它放在最后写，才使 "complete 为 true" 等价于
    # "所有产物都已落盘"。反过来写就会出现"标志已提交、数据还没写"的窗口。
    with (output / "runs.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = ["kernel", "strategy", "seed", "lanes", "cycles", "legal", "functional_pass",
                  "status", "lut", "ff", "dsp", "bram", "fmax_mhz", "time_per_vector_ns",
                  "rtl_sha256", "identical_to_seed0"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in runs:
            writer.writerow({key: record.get(key) for key in fields})
    with (output / "risk_snippets.csv").open("w", newline="", encoding="utf-8") as handle:
        fields = ["name", "group", "expected", "observed", "exact", "our_decision", "baseline_decision"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for record in risky:
            # 只投射到声明的列：record 还带 reason 等字段，直接 writerow 会因
            # "dict 含未声明键" 报错（runs.csv 同理）。列集合要显式，不能靠巧合。
            writer.writerow({
                "name": record["name"],
                "group": record["group"],
                "expected": "|".join(record["expected"]),
                "observed": "|".join(record["observed"]),
                "exact": record["exact"],
                "our_decision": record["our_decision"],
                "baseline_decision": record["baseline_decision"],
            })
    (output / "hls_generation.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return result


def refresh_backend_metadata(root: Path) -> dict[str, Any]:
    """只重算工具版本等**环境元数据**，不重跑实验。

    为什么需要这条路径：版本探测的方式本身会被修（本项目就修过一次 —— iverilog
    只认 ``-V``、gcc 不认 ``-V``），而重跑整轮实验要二十分钟、测得的数字却完全
    不变（本实验对给定输入是确定性的）。把"环境元数据"与"测量结果"分开，使前者
    可以单独刷新，且两条路径共用同一个 ``probe_backend``，不会出现两套口径。

    这里只改 ``backend`` 一个键，其它内容原样保留；``complete`` 标志必须已经是
    true，否则拒绝在未完成的清单上加工。
    """
    path = root / "paper1" / "results" / "hls_generation" / "hls_generation.json"
    if not path.exists():
        raise SystemExit(f"缺少 {path}，请先跑一次 run_hls_experiment.py")
    result = json.loads(path.read_text(encoding="utf-8"))
    if result.get("complete") is not True:
        raise SystemExit("清单的 complete 不为 true，拒绝在其上刷新元数据；请重跑整轮实验。")
    backend, _, _ = probe_backend(root)
    result["backend"] = backend
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return backend


def main() -> None:
    parser = argparse.ArgumentParser(description="论文一：解析约束驱动的 C→RTL 生成实验")
    parser.add_argument("--rows", type=int, default=VECTOR_ROWS, help="每个 kernel 的激励向量行数")
    parser.add_argument("--lane-budget", type=int, default=LANE_BUDGET, help="受预算约束的策略的最大通道数")
    parser.add_argument("--refresh-backend", action="store_true",
                        help="只刷新工具版本等环境元数据，不重跑实验")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    if args.refresh_backend:
        print(json.dumps(refresh_backend_metadata(root), ensure_ascii=False, indent=2))
        return
    result = experiment(root, max(1, args.rows), max(1, args.lane_budget))
    print(json.dumps(result["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
