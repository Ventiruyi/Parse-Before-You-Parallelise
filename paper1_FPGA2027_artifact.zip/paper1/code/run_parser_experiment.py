"""运行受控 C/HLS 风险识别基准并输出可审计统计（v2）。

分两个桶：
- **核心受控集（16 例）**：人工标注风险集合，与解析器输出做 exact-match，
  并逐类别统计 TP/FP/FN 与精度/召回。
- **鲁棒性桶（6 例）**：v1 报告缺少的反面测试。4 例断言"应当正确"
  （注释、字符串字面量、语句级数组访问、常量下标），1 例断言"应当检出"
  （嵌套块中的递归，v1 会漏），另 2 例是**已知限制**（宏别名、typedef
  自定义类型 VLA），单独计数、不混入 exact-match，避免用受控集掩盖边界。

v2 相对 v1 的变化（v1 的 15/16 中包含 1 例 safe_loop 误报）：
- safe_loop 不再误报（VLA 规则改为声明位置识别）；
- free 拆分出 dynamic_memory_release；
- 嵌套花括号中的递归可检出。
"""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from c_parser import CHLSParser

# (名称, 代码, 期望风险集合)
CASES = [
    ("safe_add", "int add(int a, int b) { return a + b; }", set()),
    ("safe_loop", "void f(int a[8]) { for (int i=0;i<8;++i) a[i] = i; }", set()),
    ("safe_static", "int f(void) { int a[16]; return a[0]; }", set()),
    ("safe_struct", "typedef struct { int x; int y; } pair; int f(pair p) { return p.x+p.y; }", set()),
    ("malloc", "void f(void) { int *p = (int*) malloc(4); free(p); }", {"dynamic_memory", "dynamic_memory_release"}),
    ("calloc", "void f(void) { int *p = (int*) calloc(4, sizeof(int)); }", {"dynamic_memory"}),
    ("realloc", "void f(int *p) { p = realloc(p, 32); }", {"dynamic_memory"}),
    ("vla", "void f(int n) { int a[n]; a[0] = 1; }", {"variable_length_array"}),
    ("vla_arg", "void f(int n, int a[n]) { a[0] = 0; }", {"variable_length_array"}),
    ("function_pointer", "int f(int (*op)(int), int x) { return op(x); }", {"function_pointer"}),
    ("function_pointer_local", "void f(void) { int (*fp)(int); return fp(1); }", {"function_pointer"}),
    ("recursion", "int fact(int n) { if (n <= 1) return 1; return n * fact(n-1); }", {"recursion"}),
    ("recursion_sum", "int sum(int n) { if (n == 0) return 0; return n + sum(n-1); }", {"recursion"}),
    ("mixed_memory_vla", "void f(int n) { int a[n]; int *p = malloc(n); free(p); }", {"dynamic_memory", "dynamic_memory_release", "variable_length_array"}),
    ("mixed_fp_vla", "void f(int n, int (*op)(int)) { int a[n]; a[0] = op(1); }", {"function_pointer", "variable_length_array"}),
    ("mixed_recursion_memory", "int f(int n) { int *p = malloc(4); free(p); if (n) return f(n-1); return 0; }", {"dynamic_memory", "dynamic_memory_release", "recursion"}),
]

# 鲁棒性：断言"应当检测到"（v1 漏检的嵌套块递归）
ROBUSTNESS_EXPECT_DETECT = [
    ("nested_block_recursion", "int f(int n) { if (n > 0) { return f(n - 1); } return 0; }", {"recursion"}),
]

# 鲁棒性：断言"应当无误报"
ROBUSTNESS_EXPECT_CLEAN = [
    ("comment_malloc", "void f(void) { /* malloc(4); free(p); */ return; }", set()),
    ("string_malloc", 'void f(void) { const char *s = "malloc(4)"; return; }', set()),
    ("array_index_not_vla", "void f(int *a, int i) { a[i] = i; return; }", set()),
    ("const_index_not_vla", "void f(void) { int a[16]; a[0] = 1; return; }", set()),
    # 回归：标识符以类型关键字结尾（myint/print）不得被当作类型，否则 a[i] 误报 VLA
    ("int_suffix_identifier", "void f(int *myint, int i) { myint[i] = 0; return; }", set()),
]

# 已知限制：期望检测但当前实现检测不到（诚实记录为边界，不计入精确率）
KNOWN_LIMITATIONS = [
    ("macro_malloc", "#define ALLOC malloc\nvoid f(void) { int *p = (int*) ALLOC(4); }", {"dynamic_memory"}),
    ("typedef_vla", "typedef int myint;\nvoid f(int n) { myint a[n]; a[0] = 1; }", {"variable_length_array"}),
]


def evaluate(parser: CHLSParser, name: str, code: str, expected: set[str]) -> dict[str, object]:
    parsed = parser.parse(code)
    observed = {item["type"] for item in parsed["issues"]}
    return {
        "name": name,
        "expected": sorted(expected),
        "observed": sorted(observed),
        "exact": observed == expected,
        "synthesizable": parsed["synthesizable"],
    }


def main() -> None:
    root = Path(__file__).resolve().parents[2]
    output = root / "paper1" / "results" / "parser_controlled"
    output.mkdir(parents=True, exist_ok=True)
    parser = CHLSParser()

    rows = [evaluate(parser, name, code, expected) for name, code, expected in CASES]
    exact = sum(bool(row["exact"]) for row in rows)

    labels = sorted({label for row in rows for label in set(row["expected"]) | set(row["observed"])})
    per_label = {}
    for label in labels:
        tp = sum(label in row["expected"] and label in row["observed"] for row in rows)
        fp = sum(label not in row["expected"] and label in row["observed"] for row in rows)
        fn = sum(label in row["expected"] and label not in row["observed"] for row in rows)
        per_label[label] = {
            "tp": tp, "fp": fp, "fn": fn,
            "precision": round(tp / (tp + fp), 4) if tp + fp else 1.0,
            "recall": round(tp / (tp + fn), 4) if tp + fn else 1.0,
        }

    detect_rows = [evaluate(parser, n, c, e) for n, c, e in ROBUSTNESS_EXPECT_DETECT]
    clean_rows = [evaluate(parser, n, c, e) for n, c, e in ROBUSTNESS_EXPECT_CLEAN]
    limit_rows = [evaluate(parser, n, c, e) for n, c, e in KNOWN_LIMITATIONS]
    robustness_passed = sum(bool(r["exact"]) for r in detect_rows + clean_rows)
    robustness_total = len(detect_rows) + len(clean_rows)

    result = {
        "experiment": "paper1_parser_controlled",
        "version": "v2",
        "core_dataset_size": len(rows),
        "core_exact_match": round(exact / len(rows), 4),
        "per_label": per_label,
        "rows": rows,
        "robustness": {
            "should_detect": detect_rows,
            "should_be_clean": clean_rows,
            "passed": robustness_passed,
            "total": robustness_total,
            "pass_rate": round(robustness_passed / robustness_total, 4),
        },
        "known_limitations": limit_rows,
        "note": "受控代码片段，不等同于 CHStone；已知限制单独计数，不混入 exact-match。",
    }
    (output / "parser_experiment.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (output / "parser_experiment.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["bucket", "name", "expected", "observed", "exact", "synthesizable"])
        writer.writeheader()
        for bucket, items in (
            ("core", rows),
            ("robust_should_detect", detect_rows),
            ("robust_should_be_clean", clean_rows),
            ("known_limitation", limit_rows),
        ):
            for row in items:
                writer.writerow({
                    "bucket": bucket,
                    "name": row["name"],
                    "expected": ";".join(row["expected"]),
                    "observed": ";".join(row["observed"]),
                    "exact": row["exact"],
                    "synthesizable": row["synthesizable"],
                })
    print(json.dumps({
        "core_dataset_size": len(rows),
        "core_exact_match": result["core_exact_match"],
        "robustness": f"{robustness_passed}/{robustness_total}",
        "known_limitations": len(limit_rows),
        "output": str(output),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
