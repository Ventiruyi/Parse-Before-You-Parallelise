module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [63:0] i_a;
  input wire [63:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [2:0] cnt;
  reg [7:0] sa, sb;
  reg [31:0] acc0;
  wire [31:0] nxt0;
  always @* begin
    case (cnt)
      3'd0: begin sa = i_a[0 +: 8]; sb = i_b[0 +: 8]; end
      3'd1: begin sa = i_a[8 +: 8]; sb = i_b[8 +: 8]; end
      3'd2: begin sa = i_a[16 +: 8]; sb = i_b[16 +: 8]; end
      3'd3: begin sa = i_a[24 +: 8]; sb = i_b[24 +: 8]; end
      3'd4: begin sa = i_a[32 +: 8]; sb = i_b[32 +: 8]; end
      3'd5: begin sa = i_a[40 +: 8]; sb = i_b[40 +: 8]; end
      3'd6: begin sa = i_a[48 +: 8]; sb = i_b[48 +: 8]; end
      3'd7: begin sa = i_a[56 +: 8]; sb = i_b[56 +: 8]; end
      default: begin sa = 8'd0; sb = 8'd0; end
    endcase
  end
  assign nxt0 = (({32'b0, sa[0 +: 8]} * {32'b0, sb[0 +: 8]}) > acc0 ? ({32'b0, sa[0 +: 8]} * {32'b0, sb[0 +: 8]}) : acc0);
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 3'd0; o_valid <= 1'b0; acc0 <= 32'd0; end
    else begin
      acc0 <= nxt0;
      if (cnt == 3'd7) begin
        o_y <= nxt0;
        o_valid <= 1'b1;
        cnt <= 3'd0;
      end else begin
        cnt <= cnt + 3'd1;
        o_valid <= 1'b0;
      end
    end
  end
endmodule
