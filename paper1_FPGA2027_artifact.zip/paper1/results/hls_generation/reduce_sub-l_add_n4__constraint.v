module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [31:0] i_a;
  input wire [31:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [1:0] cnt;
  reg [7:0] sa, sb;
  reg [31:0] acc0;
  wire [31:0] nxt0;
  always @* begin
    case (cnt)
      2'd0: begin sa = i_a[0 +: 8]; sb = i_b[0 +: 8]; end
      2'd1: begin sa = i_a[8 +: 8]; sb = i_b[8 +: 8]; end
      2'd2: begin sa = i_a[16 +: 8]; sb = i_b[16 +: 8]; end
      2'd3: begin sa = i_a[24 +: 8]; sb = i_b[24 +: 8]; end
      default: begin sa = 8'd0; sb = 8'd0; end
    endcase
  end
  assign nxt0 = (acc0 - ({32'b0, sa[0 +: 8]} + {32'b0, sb[0 +: 8]}));
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 2'd0; o_valid <= 1'b0; acc0 <= 32'd0; end
    else begin
      acc0 <= nxt0;
      if (cnt == 2'd3) begin
        o_y <= nxt0;
        o_valid <= 1'b1;
        cnt <= 2'd0;
      end else begin
        cnt <= cnt + 2'd1;
        o_valid <= 1'b0;
      end
    end
  end
endmodule
