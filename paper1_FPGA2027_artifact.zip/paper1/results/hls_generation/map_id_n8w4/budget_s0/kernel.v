module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [31:0] i_a;
  input wire [31:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [0:0] cnt;
  reg [15:0] sa, sb;
  wire [31:0] res0;
  wire [31:0] res1;
  wire [31:0] res2;
  wire [31:0] res3;
  always @* begin
    case (cnt)
      1'd0: begin sa = i_a[0 +: 16]; sb = i_b[0 +: 16]; end
      1'd1: begin sa = i_a[16 +: 16]; sb = i_b[16 +: 16]; end
      default: begin sa = 16'd0; sb = 16'd0; end
    endcase
  end
  assign res0 = {32'b0, sa[0 +: 4]};
  assign res1 = {32'b0, sa[4'd4 +: 4]};
  assign res2 = {32'b0, sa[4'd8 +: 4]};
  assign res3 = {32'b0, sa[4'd12 +: 4]};
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 1'd0; o_valid <= 1'b0; end
    else begin
      o_y[cnt * 16 + 0 +: 4] <= res0[3:0];
      o_y[cnt * 16 + 4 +: 4] <= res1[3:0];
      o_y[cnt * 16 + 8 +: 4] <= res2[3:0];
      o_y[cnt * 16 + 12 +: 4] <= res3[3:0];
      if (cnt == 1'd1) begin o_valid <= 1'b1; cnt <= 1'd0; end
      else begin o_valid <= 1'b0; cnt <= cnt + 1'd1; end
    end
  end
endmodule
