#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define N 8
#define WMASK 0xFu
typedef uint8_t elem_t;

void kernel(const elem_t *a, const elem_t *b, elem_t *y) {
    for (int i = 0; i < N; ++i) {
        y[i] = (elem_t)((a[i]) & WMASK);
    }
}

int main(int argc, char **argv) {
    FILE *fp = fopen(argv[1], "r");
    if (!fp) return 2;
    int rows = 0;
    if (fscanf(fp, "%d", &rows) != 1) return 2;
    elem_t a[N], b[N];
    for (int r = 0; r < rows; ++r) {
        for (int i = 0; i < N; ++i) { unsigned t = 0; if (fscanf(fp, "%u", &t) != 1) return 2; a[i] = (elem_t)t; }
        for (int i = 0; i < N; ++i) { unsigned t = 0; if (fscanf(fp, "%u", &t) != 1) return 2; b[i] = (elem_t)t; }
        elem_t y[N];
        kernel(a, b, y);
        for (int i = 0; i < N; ++i) printf("%u%c", (unsigned)y[i], i + 1 == N ? '\n' : ' ');
    }
    fclose(fp);
    return 0;
}
