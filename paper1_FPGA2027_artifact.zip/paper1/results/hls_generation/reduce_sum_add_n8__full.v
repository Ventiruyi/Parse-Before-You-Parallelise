module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [63:0] i_a;
  input wire [63:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [0:0] cnt;
  reg [63:0] sa, sb;
  reg [31:0] acc0;
  wire [31:0] nxt0;
  reg [31:0] acc1;
  wire [31:0] nxt1;
  reg [31:0] acc2;
  wire [31:0] nxt2;
  reg [31:0] acc3;
  wire [31:0] nxt3;
  reg [31:0] acc4;
  wire [31:0] nxt4;
  reg [31:0] acc5;
  wire [31:0] nxt5;
  reg [31:0] acc6;
  wire [31:0] nxt6;
  reg [31:0] acc7;
  wire [31:0] nxt7;
  always @* begin
    case (cnt)
      1'd0: begin sa = i_a[0 +: 64]; sb = i_b[0 +: 64]; end
      default: begin sa = 64'd0; sb = 64'd0; end
    endcase
  end
  assign nxt0 = (acc0 + ({32'b0, sa[0 +: 8]} + {32'b0, sb[0 +: 8]}));
  assign nxt1 = (acc1 + ({32'b0, sa[6'd8 +: 8]} + {32'b0, sb[6'd8 +: 8]}));
  assign nxt2 = (acc2 + ({32'b0, sa[6'd16 +: 8]} + {32'b0, sb[6'd16 +: 8]}));
  assign nxt3 = (acc3 + ({32'b0, sa[6'd24 +: 8]} + {32'b0, sb[6'd24 +: 8]}));
  assign nxt4 = (acc4 + ({32'b0, sa[6'd32 +: 8]} + {32'b0, sb[6'd32 +: 8]}));
  assign nxt5 = (acc5 + ({32'b0, sa[6'd40 +: 8]} + {32'b0, sb[6'd40 +: 8]}));
  assign nxt6 = (acc6 + ({32'b0, sa[6'd48 +: 8]} + {32'b0, sb[6'd48 +: 8]}));
  assign nxt7 = (acc7 + ({32'b0, sa[6'd56 +: 8]} + {32'b0, sb[6'd56 +: 8]}));
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 1'd0; o_valid <= 1'b0; acc0 <= 32'd0; acc1 <= 32'd0; acc2 <= 32'd0; acc3 <= 32'd0; acc4 <= 32'd0; acc5 <= 32'd0; acc6 <= 32'd0; acc7 <= 32'd0; end
    else begin
      acc0 <= nxt0;
      acc1 <= nxt1;
      acc2 <= nxt2;
      acc3 <= nxt3;
      acc4 <= nxt4;
      acc5 <= nxt5;
      acc6 <= nxt6;
      acc7 <= nxt7;
      if (cnt == 1'd0) begin
        o_y <= nxt0 + nxt1 + nxt2 + nxt3 + nxt4 + nxt5 + nxt6 + nxt7;
        o_valid <= 1'b1;
        cnt <= 1'd0;
      end else begin
        cnt <= cnt + 1'd1;
        o_valid <= 1'b0;
      end
    end
  end
endmodule
