module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [31:0] i_a;
  input wire [31:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [2:0] cnt;
  reg [3:0] sa, sb;
  wire [31:0] res0;
  always @* begin
    case (cnt)
      3'd0: begin sa = i_a[0 +: 4]; sb = i_b[0 +: 4]; end
      3'd1: begin sa = i_a[4 +: 4]; sb = i_b[4 +: 4]; end
      3'd2: begin sa = i_a[8 +: 4]; sb = i_b[8 +: 4]; end
      3'd3: begin sa = i_a[12 +: 4]; sb = i_b[12 +: 4]; end
      3'd4: begin sa = i_a[16 +: 4]; sb = i_b[16 +: 4]; end
      3'd5: begin sa = i_a[20 +: 4]; sb = i_b[20 +: 4]; end
      3'd6: begin sa = i_a[24 +: 4]; sb = i_b[24 +: 4]; end
      3'd7: begin sa = i_a[28 +: 4]; sb = i_b[28 +: 4]; end
      default: begin sa = 4'd0; sb = 4'd0; end
    endcase
  end
  assign res0 = ({32'b0, sa[0 +: 4]} + {32'b0, sb[0 +: 4]});
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 3'd0; o_valid <= 1'b0; end
    else begin
      o_y[cnt * 4 + 0 +: 4] <= res0[3:0];
      if (cnt == 3'd7) begin o_valid <= 1'b1; cnt <= 3'd0; end
      else begin o_valid <= 1'b0; cnt <= cnt + 3'd1; end
    end
  end
endmodule
