module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [31:0] i_a;
  input wire [31:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [1:0] cnt;
  reg [7:0] sa, sb;
  wire [31:0] res0;
  always @* begin
    case (cnt)
      2'd0: begin sa = i_a[0 +: 8]; sb = i_b[0 +: 8]; end
      2'd1: begin sa = i_a[8 +: 8]; sb = i_b[8 +: 8]; end
      2'd2: begin sa = i_a[16 +: 8]; sb = i_b[16 +: 8]; end
      2'd3: begin sa = i_a[24 +: 8]; sb = i_b[24 +: 8]; end
      default: begin sa = 8'd0; sb = 8'd0; end
    endcase
  end
  assign res0 = ({32'b0, sa[0 +: 8]} + {32'b0, sb[0 +: 8]});
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 2'd0; o_valid <= 1'b0; end
    else begin
      o_y[cnt * 8 + 0 +: 8] <= res0[7:0];
      if (cnt == 2'd3) begin o_valid <= 1'b1; cnt <= 2'd0; end
      else begin o_valid <= 1'b0; cnt <= cnt + 2'd1; end
    end
  end
endmodule
