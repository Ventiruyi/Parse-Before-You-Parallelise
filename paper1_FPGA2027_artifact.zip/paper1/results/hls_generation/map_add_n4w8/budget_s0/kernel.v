module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [31:0] i_a;
  input wire [31:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [0:0] cnt;
  reg [31:0] sa, sb;
  wire [31:0] res0;
  wire [31:0] res1;
  wire [31:0] res2;
  wire [31:0] res3;
  always @* begin
    case (cnt)
      1'd0: begin sa = i_a[0 +: 32]; sb = i_b[0 +: 32]; end
      default: begin sa = 32'd0; sb = 32'd0; end
    endcase
  end
  assign res0 = ({32'b0, sa[0 +: 8]} + {32'b0, sb[0 +: 8]});
  assign res1 = ({32'b0, sa[5'd8 +: 8]} + {32'b0, sb[5'd8 +: 8]});
  assign res2 = ({32'b0, sa[5'd16 +: 8]} + {32'b0, sb[5'd16 +: 8]});
  assign res3 = ({32'b0, sa[5'd24 +: 8]} + {32'b0, sb[5'd24 +: 8]});
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 1'd0; o_valid <= 1'b0; end
    else begin
      o_y[cnt * 32 + 0 +: 8] <= res0[7:0];
      o_y[cnt * 32 + 8 +: 8] <= res1[7:0];
      o_y[cnt * 32 + 16 +: 8] <= res2[7:0];
      o_y[cnt * 32 + 24 +: 8] <= res3[7:0];
      if (cnt == 1'd0) begin o_valid <= 1'b1; cnt <= 1'd0; end
      else begin o_valid <= 1'b0; cnt <= cnt + 1'd1; end
    end
  end
endmodule
