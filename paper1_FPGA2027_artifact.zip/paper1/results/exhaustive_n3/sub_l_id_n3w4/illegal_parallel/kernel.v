module kernel(clk, i_valid, i_a, i_b, o_y, o_valid);
  input wire clk;
  input wire i_valid;
  input wire [11:0] i_a;
  input wire [11:0] i_b;
  output reg [31:0] o_y;
  output reg o_valid;
  reg [0:0] cnt;
  reg [11:0] sa, sb;
  reg [31:0] acc0;
  wire [31:0] nxt0;
  reg [31:0] acc1;
  wire [31:0] nxt1;
  reg [31:0] acc2;
  wire [31:0] nxt2;
  always @* begin
    case (cnt)
      1'd0: begin sa = i_a[0 +: 12]; sb = i_b[0 +: 12]; end
      default: begin sa = 12'd0; sb = 12'd0; end
    endcase
  end
  assign nxt0 = (acc0 - {32'b0, sa[0 +: 4]});
  assign nxt1 = (acc1 - {32'b0, sa[4'd4 +: 4]});
  assign nxt2 = (acc2 - {32'b0, sa[4'd8 +: 4]});
  always @(posedge clk) begin
    if (i_valid) begin cnt <= 1'd0; o_valid <= 1'b0; acc0 <= 32'd0; acc1 <= 32'd0; acc2 <= 32'd0; end
    else begin
      acc0 <= nxt0;
      acc1 <= nxt1;
      acc2 <= nxt2;
      if (cnt == 1'd0) begin
        o_y <= nxt0 - nxt1 - nxt2;
        o_valid <= 1'b1;
        cnt <= 1'd0;
      end else begin
        cnt <= cnt + 1'd1;
        o_valid <= 1'b0;
      end
    end
  end
endmodule
